
export interface Message {
  role: 'user' | 'assistant';
  content: string;
}

export interface AttendanceRecord {
  name: string;
  nisn: string;
  className: string;
  status: 'Hadir' | 'Izin' | 'Sakit';
  timestamp: string;
}

export interface GraduationStatus {
  name: string;
  nisn: string;
  status: 'LULUS' | 'TIDAK LULUS';
  message: string;
  quote: string;
}

// E-Learning Types
export interface LearningMaterial {
  id: string;
  title: string;
  teacherName: string;
  subject: string;
  targetClass: string;
  fileUrl: string;
  timestamp: string;
}

export interface Assignment {
  id: string;
  title: string;
  description: string;
  teacherId: string;
  teacherName: string;
  subject: string;
  targetClass: string;
  deadline: string;
}

export interface Submission {
  id: string;
  assignmentId: string;
  studentNisn: string;
  studentName: string;
  content: string;
  grade?: number;
  feedback?: string;
  status: 'Pending' | 'Graded';
  timestamp: string;
}

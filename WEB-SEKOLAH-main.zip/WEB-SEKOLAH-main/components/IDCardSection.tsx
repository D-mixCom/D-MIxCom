
import React, { useState, useRef, useEffect } from 'react';
import { User, Hash, MapPin, Sparkles, Printer, GraduationCap, Calendar, Library, Camera, Trash2, Upload, Download, CheckCircle2, AlertCircle, Loader2, FileText } from 'lucide-react';
import html2canvas from 'html2canvas';

const IDCardSection: React.FC = () => {
  const [student, setStudent] = useState({
    name: '',
    nisn: '',
    ttl: '',
    agama: '',
    alamat: '',
    photo: null as string | null
  });

  const [isReady, setIsReady] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cardRef = useRef<HTMLDivElement>(null);

  // Validasi data minimal: Nama, NISN, dan Foto wajib ada
  useEffect(() => {
    const { name, nisn, photo } = student;
    setIsReady(name.trim().length >= 3 && nisn.trim().length >= 5 && photo !== null);
  }, [student]);

  const handlePrint = () => {
    if (!isReady) {
      alert("⚠️ Data Tidak Lengkap\n\nSilakan isi Nama, NISN, dan unggah Foto terlebih dahulu untuk mencetak kartu.");
      return;
    }
    // Memberikan waktu kecil agar DOM render ulang jika ada perubahan terakhir
    window.focus();
    setTimeout(() => {
      window.print();
    }, 300);
  };

  const handleDownloadPNG = async () => {
    if (!isReady || !cardRef.current || isDownloading) return;

    setIsDownloading(true);
    try {
      // Tunggu render browser untuk aset gambar
      await new Promise(resolve => setTimeout(resolve, 500));

      const canvas = await html2canvas(cardRef.current, {
        scale: 4, // 4x Resolution untuk hasil tajam (HD)
        useCORS: true,
        backgroundColor: '#050505', // Warna dasar kartu
        logging: false,
        onclone: (clonedDoc) => {
          // Pastikan elemen print-hidden tidak muncul di canvas
          const hiddenElements = clonedDoc.querySelectorAll('.print-hidden');
          hiddenElements.forEach(el => (el as HTMLElement).style.display = 'none');
        }
      });

      const image = canvas.toDataURL("image/png", 1.0);
      const link = document.createElement('a');
      link.download = `KTS_SMAN1TOJO_${student.nisn || 'STUDENT'}.png`;
      link.href = image;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (err) {
      console.error("PNG Render Error:", err);
      alert("Gagal membuat gambar. Silakan gunakan tombol 'CETAK / SIMPAN PDF'.");
    } finally {
      setIsDownloading(false);
    }
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        alert("Ukuran foto terlalu besar! Maksimal 2MB.");
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setStudent(prev => ({ ...prev, photo: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const removePhoto = () => {
    setStudent(prev => ({ ...prev, photo: null }));
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
    <section className="py-12 pb-32 relative overflow-hidden">
      {/* Background Decor */}
      <div className="absolute top-0 left-0 w-full h-full bg-blue-600/5 blur-[120px] pointer-events-none"></div>
      
      <div className="max-w-6xl mx-auto px-4 relative z-10">
        <div className="text-center mb-12 space-y-4 print:hidden">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-500 text-[10px] font-black uppercase tracking-[0.2em]">
            <Sparkles size={14} />
            E-Card Integrated System 2026
          </div>
          <h2 className="text-4xl md:text-6xl font-black leading-tight">
            ID Card <span className="text-gradient">Generator</span>
          </h2>
          <p className="text-gray-400 max-w-xl mx-auto text-lg font-medium">
            Lengkapi data diri Anda untuk mencetak Kartu Tanda Siswa (KTS) resmi SMAN 1 Tojo.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-16 items-start">
          {/* Form Section */}
          <div className="glass p-8 md:p-10 rounded-[2.5rem] border-white/10 shadow-2xl print:hidden animate-in fade-in slide-in-from-left-8 duration-700">
            <div className="flex items-center justify-between mb-8">
              <h3 className="text-2xl font-black text-white">Data Personal</h3>
              {isReady ? (
                <div className="flex items-center gap-2 text-green-400 text-xs font-bold animate-pulse">
                  <CheckCircle2 size={16} /> SIAP CETAK
                </div>
              ) : (
                <div className="flex items-center gap-2 text-gray-500 text-xs font-bold">
                  <AlertCircle size={16} /> DATA BELUM LENGKAP
                </div>
              )}
            </div>
            
            <div className="space-y-6">
              {/* Photo Input */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-gray-500 uppercase tracking-widest">Foto Identitas (Background Merah/Biru)</label>
                <div className="flex gap-5 items-center">
                  <div 
                    onClick={() => fileInputRef.current?.click()}
                    className={`w-28 h-36 rounded-2xl border-2 border-dashed flex flex-col items-center justify-center cursor-pointer transition-all relative overflow-hidden group ${student.photo ? 'border-blue-500 bg-blue-500/5' : 'border-white/10 bg-white/5 hover:border-blue-500'}`}
                  >
                    {student.photo ? (
                      <img src={student.photo} alt="Preview" className="w-full h-full object-cover" />
                    ) : (
                      <>
                        <Camera size={28} className="text-gray-500 group-hover:text-blue-500 transition-colors" />
                        <span className="text-[10px] font-bold text-gray-500 mt-2">UPLOAD</span>
                      </>
                    )}
                    <input type="file" ref={fileInputRef} onChange={handlePhotoUpload} className="hidden" accept="image/*" />
                  </div>
                  <div className="space-y-3">
                    <button 
                      onClick={() => fileInputRef.current?.click()}
                      className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-white/5 border border-white/10 text-xs font-bold hover:bg-white/10 transition-all text-white"
                    >
                      <Upload size={14} /> Pilih Foto Baru
                    </button>
                    {student.photo && (
                      <button 
                        onClick={removePhoto}
                        className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-red-500/10 border border-red-500/20 text-red-500 text-xs font-bold hover:bg-red-500/20 transition-all"
                      >
                        <Trash2 size={14} /> Hapus
                      </button>
                    )}
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-bold text-gray-500 uppercase tracking-widest">Nama Lengkap</label>
                <div className="relative">
                  <User className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" size={18} />
                  <input 
                    type="text" 
                    value={student.name}
                    onChange={(e) => setStudent({...student, name: e.target.value})}
                    className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 pl-12 pr-4 focus:outline-none focus:border-blue-500 transition-all text-white font-medium"
                    placeholder="Nama Sesuai Ijazah"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-gray-500 uppercase tracking-widest">NISN</label>
                  <div className="relative">
                    <Hash className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" size={18} />
                    <input 
                      type="text" 
                      value={student.nisn}
                      onChange={(e) => setStudent({...student, nisn: e.target.value})}
                      className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 pl-12 pr-4 focus:outline-none focus:border-blue-500 transition-all text-white font-medium"
                      placeholder="10 Digit"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-gray-500 uppercase tracking-widest">Tempat, Tgl Lahir</label>
                  <div className="relative">
                    <Calendar className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" size={18} />
                    <input 
                      type="text" 
                      value={student.ttl}
                      onChange={(e) => setStudent({...student, ttl: e.target.value})}
                      className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 pl-12 pr-4 focus:outline-none focus:border-blue-500 transition-all text-white font-medium text-sm"
                      placeholder="Tojo, 01-01-2009"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="mt-10 space-y-4">
              <div className="flex gap-4">
                <button 
                  onClick={handlePrint}
                  className={`flex-1 py-5 rounded-2xl font-black text-sm flex items-center justify-center gap-3 transition-all shadow-xl active:scale-95 ${isReady ? 'bg-white text-black hover:bg-blue-600 hover:text-white glow-blue' : 'bg-white/5 text-gray-600 border border-white/5 cursor-not-allowed'}`}
                >
                  <Printer size={22} /> CETAK / SIMPAN PDF
                </button>
                <button 
                  onClick={handleDownloadPNG}
                  disabled={!isReady || isDownloading}
                  className={`flex-1 py-5 rounded-2xl font-black text-sm flex items-center justify-center gap-3 transition-all border active:scale-95 ${isReady && !isDownloading ? 'bg-blue-600 text-white hover:bg-blue-500' : 'bg-white/5 border-white/5 text-gray-600 cursor-not-allowed'}`}
                >
                  {isDownloading ? <Loader2 size={22} className="animate-spin" /> : <Download size={22} />}
                  UNDUH PNG
                </button>
              </div>
              <p className="text-[10px] text-gray-500 text-center font-bold uppercase tracking-widest">
                💡 TIP: Pilih "Save as PDF" di menu printer untuk menyimpan file.
              </p>
            </div>
          </div>

          {/* Card Preview Section */}
          <div className="flex flex-col items-center justify-center gap-8 animate-in fade-in slide-in-from-right-8 duration-700 relative">
            <h3 className="text-xl font-bold text-gray-400 tracking-widest uppercase print:hidden">Live Preview</h3>
            
            <div 
              id="id-card-element" 
              ref={cardRef}
              className="relative w-[360px] h-[560px] md:w-[400px] md:h-[620px] rounded-[2.5rem] overflow-hidden shadow-2xl transition-all hover:rotate-1 group bg-[#050505] border border-white/10"
            >
              {/* Card Design Layers */}
              <div className="absolute inset-0 overflow-hidden pointer-events-none">
                 <div className="absolute -top-20 -right-20 w-80 h-80 bg-blue-600/20 rounded-full blur-[100px]"></div>
                 <div className="absolute -bottom-20 -left-20 w-80 h-80 bg-purple-600/20 rounded-full blur-[100px]"></div>
                 <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-[0.03] print:hidden"></div>
                 <div className="absolute inset-0 flex items-center justify-center opacity-[0.015]">
                    <GraduationCap size={300} className="-rotate-12 text-white" />
                 </div>
              </div>

              {/* Top Accent Strip */}
              <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-blue-600 via-indigo-500 to-purple-600"></div>

              {/* Main Card Content */}
              <div className="relative h-full flex flex-col p-10 z-10">
                <div className="flex items-center justify-between mb-8">
                  <div className="flex items-center gap-4">
                    <div className="w-14 h-14 bg-blue-600 rounded-2xl flex items-center justify-center shadow-lg shadow-blue-500/40">
                      <GraduationCap className="text-white" size={32} />
                    </div>
                    <div className="flex flex-col text-left">
                      <span className="text-lg font-black tracking-tight text-white leading-none">SMAN 1 TOJO</span>
                      <span className="text-[9px] text-blue-400 font-bold uppercase tracking-[0.25em] mt-1.5">Digital ID 2026/2027</span>
                    </div>
                  </div>
                  <div className="bg-white/5 border border-white/10 px-3 py-1.5 rounded-full">
                    <span className="text-[10px] font-black text-white tracking-widest">AKREDITASI A</span>
                  </div>
                </div>

                {/* Photo Section */}
                <div className="flex flex-col items-center mb-8">
                  <div className="relative">
                    <div className="w-44 h-44 rounded-[2.8rem] overflow-hidden border-4 border-blue-600/30 p-1.5 bg-[#0a0a0a] shadow-2xl relative z-10">
                      <img 
                        src={student.photo || `https://api.dicebear.com/7.x/avataaars/svg?seed=Student`} 
                        className="w-full h-full object-cover rounded-[2rem] transition-all duration-700"
                        alt="Foto Siswa"
                      />
                    </div>
                    <div className="absolute -inset-2 bg-blue-600/10 rounded-full blur-2xl group-hover:bg-blue-600/20 transition-all"></div>
                  </div>
                  
                  <div className="mt-8 text-center space-y-1">
                    <h4 className="text-2xl font-black text-white tracking-tight uppercase line-clamp-2 px-2 leading-tight">
                      {student.name || 'NAMA LENGKAP'}
                    </h4>
                    <div className="inline-block px-4 py-1.5 bg-blue-600 text-[10px] font-black text-white tracking-[0.3em] uppercase rounded-xl mt-2">
                      SISWA AKTIF
                    </div>
                  </div>
                </div>

                {/* Info List */}
                <div className="flex-1 space-y-5 text-left mt-4">
                  <div className="bg-white/5 border border-white/5 p-3.5 rounded-2xl backdrop-blur-sm">
                    <span className="text-[8px] font-black text-gray-500 uppercase tracking-widest block mb-1">NISN (Nomor Induk Siswa Nasional)</span>
                    <p className="text-base font-bold text-white tracking-[0.15em]">{student.nisn || '00XXXXXXXX'}</p>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <span className="text-[8px] font-black text-gray-500 uppercase tracking-widest">TEMPAT, TGL LAHIR</span>
                      <p className="text-[11px] font-bold text-white uppercase truncate">{student.ttl || '-'}</p>
                    </div>
                    <div className="space-y-1 text-right">
                      <span className="text-[8px] font-black text-gray-500 uppercase tracking-widest">AGAMA</span>
                      <p className="text-[11px] font-bold text-white">{student.agama || '-'}</p>
                    </div>
                  </div>

                  <div className="space-y-1">
                    <span className="text-[8px] font-black text-gray-500 uppercase tracking-widest">ALAMAT DOMISILI</span>
                    <p className="text-[11px] font-medium text-gray-300 leading-relaxed italic line-clamp-2">{student.alamat || '-'}</p>
                  </div>
                </div>

                {/* Card Footer */}
                <div className="mt-auto pt-8 border-t border-white/10 flex items-center justify-between">
                  <div className="flex flex-col items-start gap-1.5">
                    <div className="p-2 bg-white rounded-xl shadow-lg">
                      <img src={`https://api.qrserver.com/v1/create-qr-code/?size=120x120&data=SMAN1TOJO-VERIFIED-${student.nisn || 'SISWA'}&bgcolor=ffffff&color=000000`} className="w-14 h-14" alt="QR" />
                    </div>
                    <span className="text-[7px] text-gray-500 font-black tracking-widest">E-VERIFIED CARD</span>
                  </div>
                  
                  <div className="text-right">
                     <p className="text-[8px] text-gray-500 font-bold mb-1 uppercase">Kepala Sekolah</p>
                     <div className="h-10 w-28 relative ml-auto flex justify-end">
                        <img src="https://upload.wikimedia.org/wikipedia/commons/3/3a/Jon_Kirsch%27s_Signature.png" className="w-full h-full object-contain invert opacity-70" alt="Sign" />
                     </div>
                     <p className="text-[9px] font-black text-white mt-1 border-b border-white/30 inline-block uppercase">Drs Sarimin R Jalini</p>
                     <p className="text-[7px] text-gray-500 font-bold mt-0.5">NIP. 19720815 199801 1 001</p>
                  </div>
                </div>
              </div>

              {/* Interactive Glare Overlay (Hidden on Print) */}
              <div className="absolute inset-0 pointer-events-none bg-gradient-to-tr from-transparent via-white/5 to-transparent -translate-x-full group-hover:translate-x-full transition-all duration-1000 print:hidden"></div>
            </div>

            <p className="text-xs text-gray-500 text-center max-w-[320px] leading-relaxed print:hidden">
              Gunakan kertas Foto atau PVC 0.76mm untuk hasil cetak ID Card yang maksimal dan tahan lama.
            </p>
          </div>
        </div>
      </div>

      {/* Optimized Print Styles */}
      <style>{`
        @media print {
          @page {
            size: A4 portrait;
            margin: 0;
          }
          
          /* Hilangkan elemen yang tidak perlu */
          body {
            background: white !important;
            margin: 0 !important;
            padding: 0 !important;
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
          }
          
          /* Sembunyikan semua kecuali elemen kartu */
          body * { 
            visibility: hidden !important;
            display: none !important;
          }
          
          /* Tampilkan kontainer kartu */
          #id-card-element, #id-card-element * { 
            visibility: visible !important;
            display: flex !important;
          }
          
          #id-card-element {
            display: block !important;
            position: fixed !important;
            left: 50% !important;
            top: 50% !important;
            transform: translate(-50%, -50%) scale(1.4) !important;
            box-shadow: none !important;
            border: 1px solid #333 !important;
            background-color: #050505 !important;
            width: 400px !important;
            height: 620px !important;
            border-radius: 2.5rem !important;
            overflow: hidden !important;
            z-index: 9999 !important;
          }

          /* Pastikan teks tetap kontras */
          .text-white { color: white !important; }
          .text-gray-500 { color: #888888 !important; }
          .bg-blue-600 { background-color: #2563eb !important; }
          .text-blue-400 { color: #60a5fa !important; }
          
          /* Elemen footer kartu */
          #id-card-element .mt-auto {
             display: flex !important;
             flex-direction: row !important;
          }
          
          /* Sembunyikan elemen dekoratif yang mengganggu print */
          .print-hidden, .group-hover\:translate-x-full { display: none !important; }
        }
      `}</style>
    </section>
  );
};

export default IDCardSection;

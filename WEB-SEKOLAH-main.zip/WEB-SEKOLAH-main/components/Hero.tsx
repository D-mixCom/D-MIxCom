
import React from 'react';
import { ArrowRight, Play, Sparkles } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <section className="relative min-h-screen flex items-center pt-20 overflow-hidden">
      {/* Background Decor */}
      <div className="absolute top-1/4 -left-20 w-96 h-96 bg-blue-600/20 rounded-full blur-[120px] pointer-events-none"></div>
      <div className="absolute bottom-1/4 -right-20 w-96 h-96 bg-purple-600/20 rounded-full blur-[120px] pointer-events-none"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-bold tracking-wider uppercase">
              <Sparkles size={14} />
              Era Baru Pendidikan 2026
            </div>
            
            <h1 className="text-5xl md:text-7xl font-extrabold leading-[1.1] tracking-tight">
              Membangun <span className="text-gradient">Masa Depan</span> dari Tojo.
            </h1>
            
            <p className="text-lg text-gray-400 max-w-lg leading-relaxed">
              SMAN 1 Tojo hadir dengan kurikulum inovatif berbasis teknologi untuk mencetak generasi pemimpin yang adaptif, kreatif, dan berintegritas.
            </p>
            
            <div className="flex flex-wrap gap-4">
              <button className="bg-blue-600 hover:bg-blue-500 text-white px-8 py-4 rounded-2xl font-bold flex items-center gap-2 transition-all glow-blue">
                Mulai Menjelajah <ArrowRight size={20} />
              </button>
              <button className="glass hover:bg-white/10 text-white px-8 py-4 rounded-2xl font-bold flex items-center gap-2 transition-all">
                <Play size={20} className="fill-white" /> Lihat Profil
              </button>
            </div>

            <div className="flex items-center gap-8 pt-4">
              <div>
                <div className="text-3xl font-bold">1.2K+</div>
                <div className="text-sm text-gray-500">Siswa Aktif</div>
              </div>
              <div className="w-px h-10 bg-white/10"></div>
              <div>
                <div className="text-3xl font-bold">98%</div>
                <div className="text-sm text-gray-500">Lulus PTN</div>
              </div>
              <div className="w-px h-10 bg-white/10"></div>
              <div>
                <div className="text-3xl font-bold">50+</div>
                <div className="text-sm text-gray-500">Prestasi Nasional</div>
              </div>
            </div>
          </div>

          <div className="relative">
            <div className="relative rounded-[2rem] overflow-hidden border border-white/10 shadow-2xl animate-float">
              <img 
                src="https://picsum.photos/seed/school/800/1000" 
                alt="Students" 
                className="w-full h-auto object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent"></div>
              <div className="absolute bottom-8 left-8 right-8 glass p-6 rounded-2xl">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-full overflow-hidden border-2 border-blue-500">
                    <img src="https://picsum.photos/seed/head/100/100" alt="Alumni" />
                  </div>
                  <div>
                    <div className="text-sm font-bold">Andi Pratama</div>
                    <div className="text-xs text-blue-400">Alumni SMAN 1 Tojo - Harvard Scholar</div>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Decorative Elements */}
            <div className="absolute -top-6 -right-6 w-24 h-24 glass rounded-2xl flex items-center justify-center rotate-12">
              <div className="text-2xl font-bold text-blue-500">A+</div>
            </div>
            <div className="absolute -bottom-10 -left-10 glass p-4 rounded-2xl hidden md:block">
              <div className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-1">Akreditasi</div>
              <div className="text-xl font-black">UNGGUL (A)</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;


import React, { useState, useEffect } from 'react';
import { Menu, X, GraduationCap, Calendar, CheckSquare, Contact2, BookOpen, UserPlus } from 'lucide-react';

interface NavbarProps {
  onNavigate: (view: 'home' | 'kelulusan' | 'absensi' | 'id-card' | 'elearning' | 'ppdb') => void;
  currentView: string;
}

const Navbar: React.FC<NavbarProps> = ({ onNavigate, currentView }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { label: 'Beranda', id: 'home', icon: null },
    { label: 'Profil', id: 'profil', isAnchor: true },
    { label: 'PPDB', id: 'ppdb', icon: <UserPlus size={14} className="mr-1" /> },
    { label: 'e-Learning', id: 'elearning', icon: <BookOpen size={14} className="mr-1" /> },
    { label: 'Kelulusan', id: 'kelulusan', icon: <Calendar size={14} className="mr-1" /> },
    { label: 'Absensi', id: 'absensi', icon: <CheckSquare size={14} className="mr-1" /> },
    { label: 'ID Card', id: 'id-card', icon: <Contact2 size={14} className="mr-1" /> },
    { label: 'Kontak', id: 'kontak', isAnchor: true }
  ];

  const handleNavClick = (id: string, isAnchor?: boolean) => {
    if (isAnchor) {
      if (currentView !== 'home') {
        onNavigate('home' as any);
        setTimeout(() => {
          const el = document.getElementById(id);
          el?.scrollIntoView({ behavior: 'smooth' });
        }, 100);
      } else {
        const el = document.getElementById(id);
        el?.scrollIntoView({ behavior: 'smooth' });
      }
    } else {
      onNavigate(id as any);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
    setIsMobileMenuOpen(false);
  };

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${isScrolled ? 'py-3' : 'py-6'}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className={`glass rounded-2xl px-6 py-3 flex items-center justify-between transition-all duration-300 ${isScrolled ? 'bg-black/60 shadow-xl' : 'bg-white/5'}`}>
          <div 
            className="flex items-center gap-3 cursor-pointer group"
            onClick={() => handleNavClick('home')}
          >
            <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center glow-blue group-hover:scale-110 transition-transform">
              <GraduationCap className="text-white" size={24} />
            </div>
            <div className="flex flex-col text-white">
              <span className="text-lg font-bold tracking-tight">SMAN 1 TOJO</span>
              <span className="text-[10px] text-blue-400 font-semibold tracking-widest uppercase">Smart & Modern</span>
            </div>
          </div>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-2">
            {navItems.map((item) => (
              <button 
                key={item.label} 
                onClick={() => handleNavClick(item.id, item.isAnchor)}
                className={`text-[13px] font-bold transition-all flex items-center px-3 py-2 rounded-xl ${
                  (currentView === item.id) 
                    ? 'text-white bg-blue-600' 
                    : 'text-gray-400 hover:text-white hover:bg-white/5'
                }`}
              >
                {item.icon}
                {item.label}
              </button>
            ))}
            <button 
              onClick={() => handleNavClick('ppdb')}
              className="bg-white text-black px-5 py-2 rounded-xl text-xs font-black hover:bg-blue-500 hover:text-white transition-all duration-300 ml-4"
            >
              DAFTAR SEKARANG
            </button>
          </div>

          {/* Mobile Menu Toggle */}
          <button 
            className="md:hidden p-2 text-gray-300"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden absolute top-24 left-4 right-4 z-40">
          <div className="glass rounded-2xl p-6 flex flex-col gap-4 shadow-2xl animate-in slide-in-from-top-4 duration-300">
            {navItems.map((item) => (
              <button 
                key={item.label} 
                className={`text-lg font-semibold border-b border-white/5 pb-2 flex items-center ${
                  currentView === item.id ? 'text-blue-400' : 'text-gray-200'
                }`}
                onClick={() => handleNavClick(item.id, item.isAnchor)}
              >
                {item.icon}
                <span className={item.icon ? 'ml-2' : ''}>{item.label}</span>
              </button>
            ))}
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;

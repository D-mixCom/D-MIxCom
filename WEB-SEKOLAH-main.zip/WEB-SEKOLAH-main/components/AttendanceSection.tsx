
import React, { useState, useEffect } from 'react';
import { User, Hash, School, CheckCircle, Send, QrCode, MapPin, ShieldCheck, AlertTriangle } from 'lucide-react';

const SCHOOL_COORDS = {
  lat: -1.42301422390578,
  lng: 121.12054048660936
};
const MAX_DISTANCE_METERS = 50000;

const AttendanceSection: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    nisn: '',
    class: '',
    status: 'Hadir'
  });
  
  const [location, setLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [distance, setDistance] = useState<number | null>(null);
  const [locationError, setLocationError] = useState<string | null>(null);
  const [isLocating, setIsLocating] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  // Haversine formula to calculate distance in meters
  const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number) => {
    const R = 6371e3; // Earth radius in meters
    const φ1 = lat1 * Math.PI / 180;
    const φ2 = lat2 * Math.PI / 180;
    const Δφ = (lat2 - lat1) * Math.PI / 180;
    const Δλ = (lon2 - lon1) * Math.PI / 180;

    const a = Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
              Math.cos(φ1) * Math.cos(φ2) *
              Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

    return R * c;
  };

  const verifyLocation = () => {
    setIsLocating(true);
    setLocationError(null);

    if (!navigator.geolocation) {
      setLocationError("Geolokasi tidak didukung oleh browser Anda.");
      setIsLocating(false);
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude } = position.coords;
        const d = calculateDistance(latitude, longitude, SCHOOL_COORDS.lat, SCHOOL_COORDS.lng);
        setLocation({ lat: latitude, lng: longitude });
        setDistance(d);
        setIsLocating(false);
      },
      (error) => {
        let msg = "Gagal mengambil lokasi.";
        if (error.code === 1) msg = "Izin lokasi ditolak. Harap aktifkan GPS.";
        else if (error.code === 2) msg = "Posisi tidak tersedia.";
        setLocationError(msg);
        setIsLocating(false);
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
    );
  };

  const isWithinRange = distance !== null && distance <= MAX_DISTANCE_METERS;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isWithinRange) {
      setLocationError(`Anda berada di luar jangkauan (${distance?.toFixed(1)}m). Jarak maksimal adalah ${MAX_DISTANCE_METERS}m.`);
      return;
    }

    setLoading(true);
    // Simulate submission
    setTimeout(() => {
      setLoading(false);
      setIsSubmitted(true);
      setTimeout(() => setIsSubmitted(false), 5000);
      setFormData({ name: '', nisn: '', class: '', status: 'Hadir' });
      setLocation(null);
      setDistance(null);
    }, 2000);
  };

  return (
    <section id="absensi" className="py-24 bg-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div className="space-y-8">
            <div className="space-y-4">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-[10px] font-black uppercase tracking-widest">
                <ShieldCheck size={14} />
                Secure Geofencing Active
              </div>
              <h2 className="text-4xl md:text-5xl font-black">Portal <span className="text-gradient">Absensi Online</span></h2>
              <p className="text-gray-400 leading-relaxed text-lg">
                Sistem absensi cerdas SMAN 1 Tojo. Anda diwajibkan melakukan verifikasi lokasi dalam radius <strong>50 meter</strong> dari koordinat sekolah untuk dapat melakukan absensi.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className={`glass p-6 rounded-3xl space-y-2 border transition-colors ${isWithinRange ? 'border-green-500/30' : 'border-white/10'}`}>
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${isWithinRange ? 'bg-green-500/20 text-green-500' : 'bg-blue-500/20 text-blue-500'}`}>
                  <MapPin size={20} />
                </div>
                <div className="text-xl font-bold">Verifikasi Geo</div>
                <div className="text-xs text-gray-500">
                  {distance !== null ? `Jarak: ${distance.toFixed(1)} meter` : 'Belum diverifikasi'}
                </div>
              </div>
              <div className="glass p-6 rounded-3xl space-y-2 border border-white/10">
                <div className="w-10 h-10 bg-blue-500/20 text-blue-500 rounded-xl flex items-center justify-center">
                  <QrCode size={20} />
                </div>
                <div className="text-xl font-bold">Smart Scan</div>
                <div className="text-xs text-gray-500">Integrasi ID Card Digital 2026.</div>
              </div>
            </div>
          </div>

          <div className="relative">
            <div className="glass p-8 md:p-10 rounded-[2.5rem] shadow-2xl border-white/10 relative z-10">
              {isSubmitted ? (
                <div className="text-center py-12 space-y-4 animate-in zoom-in duration-500">
                  <div className="w-20 h-20 bg-green-500 text-white rounded-full flex items-center justify-center mx-auto mb-6 shadow-2xl shadow-green-500/20">
                    <CheckCircle size={40} />
                  </div>
                  <h3 className="text-2xl font-bold">Absensi Berhasil!</h3>
                  <p className="text-gray-400">Data kehadiran Anda telah tercatat dengan validasi lokasi pada pukul {new Date().toLocaleTimeString()}.</p>
                  <button 
                    onClick={() => setIsSubmitted(false)}
                    className="text-blue-500 font-bold hover:underline"
                  >
                    Kirim lagi
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="space-y-4">
                    <div className="relative">
                      <User className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" size={18} />
                      <input 
                        required
                        type="text" 
                        placeholder="Nama Lengkap"
                        value={formData.name}
                        onChange={e => setFormData({...formData, name: e.target.value})}
                        className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 pl-12 pr-4 focus:outline-none focus:border-blue-500 transition-all"
                      />
                    </div>
                    <div className="relative">
                      <Hash className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" size={18} />
                      <input 
                        required
                        type="text" 
                        placeholder="NISN"
                        value={formData.nisn}
                        onChange={e => setFormData({...formData, nisn: e.target.value})}
                        className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 pl-12 pr-4 focus:outline-none focus:border-blue-500 transition-all"
                      />
                    </div>
                    <div className="relative">
                      <School className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" size={18} />
                      <select 
                        required
                        value={formData.class}
                        onChange={e => setFormData({...formData, class: e.target.value})}
                        className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 pl-12 pr-4 focus:outline-none focus:border-blue-500 transition-all appearance-none text-gray-400"
                      >
                        <option value="" disabled>Pilih Kelas</option>
                        <option value="X-1">Kelas X - 1</option>
                        <option value="X-2">Kelas X - 2</option>
                        <option value="XI-IPA-1">Kelas XI - IPA 1</option>
                        <option value="XI-IPS-1">Kelas XI - IPS 1</option>
                        <option value="XII-IPA-1">Kelas XII - IPA 1</option>
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-3">
                    {['Hadir', 'Izin', 'Sakit'].map((s) => (
                      <button
                        key={s}
                        type="button"
                        onClick={() => setFormData({...formData, status: s as any})}
                        className={`py-3 rounded-2xl text-xs font-bold transition-all border ${formData.status === s ? 'bg-blue-600 border-blue-600 text-white shadow-lg' : 'bg-white/5 border-white/10 text-gray-400 hover:bg-white/10'}`}
                      >
                        {s}
                      </button>
                    ))}
                  </div>

                  {/* Location Action */}
                  <div className="space-y-3">
                    <button
                      type="button"
                      onClick={verifyLocation}
                      disabled={isLocating}
                      className={`w-full py-4 rounded-2xl font-bold flex items-center justify-center gap-2 transition-all border ${isWithinRange ? 'bg-green-500/10 border-green-500/30 text-green-500' : 'bg-white/5 border-white/10 text-white hover:bg-white/10'}`}
                    >
                      {isLocating ? (
                        <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                      ) : (
                        <>
                          <MapPin size={18} /> {isWithinRange ? 'Lokasi Terverifikasi' : 'Cek Lokasi Saya'}
                        </>
                      )}
                    </button>

                    {locationError && (
                      <div className="p-4 bg-red-500/10 border border-red-500/20 rounded-2xl flex items-start gap-3 text-red-400 text-xs animate-in slide-in-from-top-2">
                        <AlertTriangle size={16} className="flex-shrink-0 mt-0.5" />
                        <p>{locationError}</p>
                      </div>
                    )}
                  </div>

                  <button 
                    type="submit"
                    disabled={loading || !isWithinRange}
                    className={`w-full py-4 rounded-2xl font-bold flex items-center justify-center gap-2 transition-all group shadow-xl ${isWithinRange ? 'bg-white text-black hover:bg-blue-600 hover:text-white' : 'bg-white/5 text-gray-600 cursor-not-allowed border border-white/5'}`}
                  >
                    {loading ? <div className="w-5 h-5 border-2 border-black/30 border-t-black rounded-full animate-spin"></div> : (
                      <>
                        Kirim Kehadiran <Send size={18} className="group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
                      </>
                    )}
                  </button>
                </form>
              )}
            </div>
            {/* Background Glow */}
            <div className="absolute -top-10 -right-10 w-64 h-64 bg-blue-600/10 rounded-full blur-[100px] pointer-events-none"></div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AttendanceSection;

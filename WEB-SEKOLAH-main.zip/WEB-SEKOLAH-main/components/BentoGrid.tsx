
import React from 'react';
import { Cpu, Globe, BookOpen, Users, Trophy, Lightbulb } from 'lucide-react';

const BentoGrid: React.FC = () => {
  return (
    <section id="akademik" className="py-24 bg-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16 space-y-4">
          <h2 className="text-4xl md:text-5xl font-extrabold tracking-tight">Kenapa Memilih <span className="text-gradient">Kami?</span></h2>
          <p className="text-gray-400 max-w-2xl mx-auto">Kami mengintegrasikan teknologi terkini dengan pendidikan karakter untuk menciptakan ekosistem belajar terbaik.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 grid-rows-2 gap-4 h-auto md:h-[600px]">
          {/* Main Feature */}
          <div className="md:col-span-2 md:row-span-2 glass rounded-[2.5rem] p-8 flex flex-col justify-between hover:bg-white/5 transition-all group overflow-hidden relative">
            <div className="absolute -right-20 -top-20 w-64 h-64 bg-blue-600/10 rounded-full blur-3xl group-hover:bg-blue-600/20 transition-all"></div>
            <div className="space-y-4 relative z-10">
              <div className="w-14 h-14 bg-blue-600 rounded-2xl flex items-center justify-center glow-blue">
                <Cpu className="text-white" size={28} />
              </div>
              <h3 className="text-3xl font-bold">Laboratorium Komputer AI</h3>
              <p className="text-gray-400 leading-relaxed">Fasilitas riset berbasis kecerdasan buatan untuk mempersiapkan siswa menghadapi industri digital masa depan.</p>
            </div>
            <div className="mt-8 relative z-10">
              <img src="https://picsum.photos/seed/lab/600/300" alt="Lab" className="rounded-2xl w-full object-cover h-40 opacity-50 group-hover:opacity-100 transition-opacity" />
            </div>
          </div>

          {/* Secondary 1 */}
          <div className="md:col-span-1 glass rounded-[2.5rem] p-8 flex flex-col justify-between hover:bg-white/5 transition-all">
            <div className="w-12 h-12 bg-purple-600 rounded-2xl flex items-center justify-center">
              <Globe className="text-white" size={24} />
            </div>
            <div>
              <h3 className="text-xl font-bold">Global Network</h3>
              <p className="text-sm text-gray-500 mt-2">Kerjasama internasional dengan sekolah di mancanegara.</p>
            </div>
          </div>

          {/* Secondary 2 */}
          <div className="md:col-span-1 glass rounded-[2.5rem] p-8 flex flex-col justify-between hover:bg-white/5 transition-all">
            <div className="w-12 h-12 bg-green-600 rounded-2xl flex items-center justify-center">
              <BookOpen className="text-white" size={24} />
            </div>
            <div>
              <h3 className="text-xl font-bold">Digital Library</h3>
              <p className="text-sm text-gray-500 mt-2">Akses ke ribuan jurnal dan ebook dari mana saja.</p>
            </div>
          </div>

          {/* Long Item */}
          <div className="md:col-span-2 glass rounded-[2.5rem] p-8 flex items-center justify-between hover:bg-white/5 transition-all">
            <div className="space-y-2">
              <h3 className="text-2xl font-bold">Ekstrakurikuler Unggulan</h3>
              <p className="text-gray-400 text-sm">Robotik, Esport, Pramuka, dan Seni Budaya.</p>
            </div>
            <div className="flex -space-x-4">
              {[1,2,3,4].map(i => (
                <div key={i} className="w-12 h-12 rounded-full border-4 border-black overflow-hidden">
                  <img src={`https://picsum.photos/seed/student${i}/100/100`} alt="Stud" />
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default BentoGrid;

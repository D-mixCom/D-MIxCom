
import React, { useState, useRef, useEffect } from 'react';
import { UserPlus, User, MapPin, Phone, Mail, BookOpen, CheckCircle, ArrowRight, ShieldCheck, Heart, Users, FileText, Settings, Trash2, Upload, FileUp, Image as ImageIcon, CreditCard, FileCheck, LocateFixed, Navigation, AlertTriangle } from 'lucide-react';

const SCHOOL_COORDS = {
  lat: -1.4229927728516325,
  lng: 121.12067996147537
};
const MAX_DISTANCE_KM = 50;

const PPDBSection: React.FC = () => {
  const [step, setStep] = useState(1);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [isAdminView, setIsAdminView] = useState(false);
  const [registrations, setRegistrations] = useState<any[]>([]);

  // Location Verification State
  const [isLocating, setIsLocating] = useState(false);
  const [userCoords, setUserCoords] = useState<{ lat: number; lng: number } | null>(null);
  const [distance, setDistance] = useState<number | null>(null);
  const [locationError, setLocationError] = useState<string | null>(null);

  // Form State Based on Dapodik + Document Uploads
  const [formData, setFormData] = useState({
    namaLengkap: '',
    jenisKelamin: '',
    nisn: '',
    nik: '',
    tempatLahir: '',
    tanggalLahir: '',
    agama: '',
    kebutuhanKhusus: 'Tidak Ada',
    alamatJalan: '',
    rt: '',
    rw: '',
    dusun: '',
    kelurahan: '',
    kecamatan: '',
    kodePos: '',
    tempatTinggal: 'Bersama Orang Tua',
    namaAyah: '',
    nikAyah: '',
    pendidikanAyah: '',
    pekerjaanAyah: '',
    penghasilanAyah: '',
    namaIbu: '',
    nikIbu: '',
    pendidikanIbu: '',
    pekerjaanIbu: '',
    penghasilanIbu: '',
    sekolahAsal: '',
    tahunLulus: '',
    fileFoto: null as string | null,
    fileKK: null as string | null,
    fileKIP: null as string | null,
    fileIjazah: null as string | null,
    fileSKL: null as string | null
  });

  const fileRefs = {
    foto: useRef<HTMLInputElement>(null),
    kk: useRef<HTMLInputElement>(null),
    kip: useRef<HTMLInputElement>(null),
    ijazah: useRef<HTMLInputElement>(null),
    skl: useRef<HTMLInputElement>(null),
  };

  const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number) => {
    const R = 6371; // Radius bumi dalam KM
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
              Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
              Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  };

  const verifyLocation = () => {
    setIsLocating(true);
    setLocationError(null);

    if (!navigator.geolocation) {
      setLocationError("Browser Anda tidak mendukung geolokasi.");
      setIsLocating(false);
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude } = position.coords;
        const dist = calculateDistance(latitude, longitude, SCHOOL_COORDS.lat, SCHOOL_COORDS.lng);
        setUserCoords({ lat: latitude, lng: longitude });
        setDistance(dist);
        setIsLocating(false);
      },
      (error) => {
        let msg = "Gagal mendapatkan lokasi.";
        if (error.code === 1) msg = "Izin lokasi ditolak. Harap izinkan akses GPS untuk validasi zonasi.";
        setLocationError(msg);
        setIsLocating(false);
      },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, field: string) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        alert("Ukuran file terlalu besar! Maksimal 5MB.");
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData(prev => ({ ...prev, [field]: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const removeFile = (field: string) => {
    setFormData(prev => ({ ...prev, [field]: null }));
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const nextStep = () => {
    if (step === 2) {
      if (!distance) {
        alert("Harap verifikasi lokasi domisili Anda untuk validasi zonasi.");
        return;
      }
      if (distance > MAX_DISTANCE_KM) {
        alert(`Lokasi Anda (${distance.toFixed(1)}km) melebihi radius zonasi maksimal (${MAX_DISTANCE_KM}km).`);
        return;
      }
    }
    setStep(prev => Math.min(prev + 1, 5));
  };
  
  const prevStep = () => setStep(prev => Math.max(prev - 1, 1));

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.fileFoto || !formData.fileKK || !formData.fileIjazah || !formData.fileSKL) {
      alert("Harap unggah semua dokumen wajib.");
      return;
    }

    setLoading(true);
    setTimeout(() => {
      const regId = 'PPDB-' + Math.random().toString(36).substr(2, 9).toUpperCase();
      const newReg = { ...formData, id: regId, timestamp: new Date().toLocaleString(), distance };
      setRegistrations(prev => [...prev, newReg]);
      setLoading(false);
      setIsSubmitted(true);
    }, 2000);
  };

  const deleteRegistration = (id: string) => {
    setRegistrations(prev => prev.filter(r => r.id !== id));
  };

  if (isSubmitted) {
    return (
      <section className="py-24 max-w-3xl mx-auto px-4">
        <div className="glass p-12 rounded-[3rem] text-center space-y-8 animate-in zoom-in duration-500 border-green-500/20">
          <div className="w-24 h-24 bg-green-500 text-white rounded-full flex items-center justify-center mx-auto shadow-2xl shadow-green-500/30">
            <CheckCircle size={48} />
          </div>
          <div className="space-y-4">
            <h2 className="text-4xl font-black text-white">Pendaftaran Berhasil!</h2>
            <p className="text-gray-400 text-lg">
              Selamat, <strong>{formData.namaLengkap}</strong>. Lokasi Anda terverifikasi dalam radius zonasi ({distance?.toFixed(1)}km). Data Anda telah kami terima.
            </p>
          </div>
          <div className="p-6 bg-white/5 rounded-3xl border border-white/10 inline-block">
             <p className="text-[10px] uppercase font-black text-gray-500 tracking-[0.3em] mb-2">Registration ID</p>
             <p className="text-2xl font-black text-blue-500 tracking-wider">#{registrations[registrations.length-1]?.id}</p>
          </div>
          <div className="pt-8">
            <button 
              onClick={() => {
                setIsSubmitted(false);
                setStep(1);
                setDistance(null);
                setFormData({
                    namaLengkap: '', jenisKelamin: '', nisn: '', nik: '', tempatLahir: '', tanggalLahir: '', agama: '', kebutuhanKhusus: 'Tidak Ada',
                    alamatJalan: '', rt: '', rw: '', dusun: '', kelurahan: '', kecamatan: '', kodePos: '', tempatTinggal: 'Bersama Orang Tua',
                    namaAyah: '', nikAyah: '', pendidikanAyah: '', pekerjaanAyah: '', penghasilanAyah: '',
                    namaIbu: '', nikIbu: '', pendidikanIbu: '', pekerjaanIbu: '', penghasilanIbu: '',
                    sekolahAsal: '', tahunLulus: '',
                    fileFoto: null, fileKK: null, fileKIP: null, fileIjazah: null, fileSKL: null
                });
              }}
              className="px-10 py-4 bg-white text-black rounded-2xl font-black hover:bg-blue-600 hover:text-white transition-all"
            >
              DAFTAR BARU
            </button>
          </div>
        </div>
      </section>
    );
  }

  if (isAdminView) {
    return (
      <section className="py-12 max-w-7xl mx-auto px-4">
        <div className="flex justify-between items-center mb-12">
           <h2 className="text-3xl font-black text-white flex items-center gap-3">
             <Settings className="text-blue-500" /> Database PPDB 2026
           </h2>
           <button 
             onClick={() => setIsAdminView(false)}
             className="px-6 py-2 bg-white/5 border border-white/10 rounded-xl text-xs font-bold text-gray-400 hover:text-white transition-all"
           >
             Kembali ke Form
           </button>
        </div>

        <div className="glass rounded-[2.5rem] border-white/10 overflow-hidden overflow-x-auto">
           <table className="w-full text-left">
              <thead>
                 <tr className="bg-white/5 border-b border-white/10">
                    <th className="p-6 text-[10px] font-black uppercase text-gray-500 tracking-widest">Waktu</th>
                    <th className="p-6 text-[10px] font-black uppercase text-gray-500 tracking-widest">ID</th>
                    <th className="p-6 text-[10px] font-black uppercase text-gray-500 tracking-widest">Nama Pendaftar</th>
                    <th className="p-6 text-[10px] font-black uppercase text-gray-500 tracking-widest">Zonasi (KM)</th>
                    <th className="p-6 text-[10px] font-black uppercase text-gray-500 tracking-widest">Berkas</th>
                    <th className="p-6 text-[10px] font-black uppercase text-gray-500 tracking-widest">Aksi</th>
                 </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                 {registrations.length === 0 ? (
                    <tr>
                       <td colSpan={6} className="p-12 text-center text-gray-500 text-sm">Belum ada pendaftar baru.</td>
                    </tr>
                 ) : (
                    registrations.map(reg => (
                       <tr key={reg.id} className="hover:bg-white/5 transition-colors">
                          <td className="p-6 text-xs text-gray-400">{reg.timestamp}</td>
                          <td className="p-6 text-xs font-bold text-blue-500">#{reg.id}</td>
                          <td className="p-6 text-sm font-bold text-white">{reg.namaLengkap}</td>
                          <td className="p-6 text-xs font-bold text-yellow-500">{reg.distance?.toFixed(2)} km</td>
                          <td className="p-6">
                             <div className="flex gap-2">
                               {reg.fileFoto && <div className="w-6 h-6 rounded bg-blue-500/20 flex items-center justify-center text-blue-500"><ImageIcon size={12} /></div>}
                               {reg.fileKK && <div className="w-6 h-6 rounded bg-green-500/20 flex items-center justify-center text-green-500"><FileText size={12} /></div>}
                             </div>
                          </td>
                          <td className="p-6">
                             <button onClick={() => deleteRegistration(reg.id)} className="text-red-500 hover:bg-red-500/10 p-2 rounded-lg transition-all">
                                <Trash2 size={16} />
                             </button>
                          </td>
                       </tr>
                    ))
                 )}
              </tbody>
           </table>
        </div>
      </section>
    );
  }

  const DocumentUploadBox = ({ title, field, icon: Icon, required = true }: { title: string, field: string, icon: any, required?: boolean }) => (
    <div className="space-y-3">
      <div className="flex justify-between items-center">
        <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest">
          {title} {required && <span className="text-red-500">*</span>}
        </label>
        {formData[field as keyof typeof formData] && (
          <button type="button" onClick={() => removeFile(field)} className="text-[9px] font-bold text-red-500 hover:underline">Hapus</button>
        )}
      </div>
      <div 
        onClick={() => fileRefs[field.replace('file', '').toLowerCase() as keyof typeof fileRefs].current?.click()}
        className={`relative h-32 rounded-2xl border-2 border-dashed transition-all flex flex-col items-center justify-center cursor-pointer overflow-hidden ${formData[field as keyof typeof formData] ? 'border-green-500/50 bg-green-500/5' : 'border-white/10 bg-white/5 hover:border-blue-500/50'}`}
      >
        {formData[field as keyof typeof formData] ? (
          <div className="flex flex-col items-center gap-2">
             <FileCheck className="text-green-500" size={24} />
             <span className="text-[10px] font-bold text-green-500 uppercase">File Terunggah</span>
             {field === 'fileFoto' && <img src={formData[field] as string} className="absolute inset-0 w-full h-full object-cover opacity-20 pointer-events-none" />}
          </div>
        ) : (
          <>
            <Icon className="text-gray-500 mb-2" size={24} />
            <span className="text-[10px] font-bold text-gray-500 uppercase tracking-wider">Klik untuk Upload</span>
          </>
        )}
        <input 
          type="file" 
          ref={fileRefs[field.replace('file', '').toLowerCase() as keyof typeof fileRefs]} 
          onChange={(e) => handleFileChange(e, field)} 
          className="hidden" 
          accept={field === 'fileFoto' ? 'image/*' : '.pdf,.jpg,.jpeg,.png'} 
        />
      </div>
    </div>
  );

  return (
    <section className="py-12 max-w-5xl mx-auto px-4">
      <div className="flex justify-between items-center mb-12">
        <div className="space-y-4">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-500 text-[10px] font-black uppercase tracking-[0.2em]">
            <UserPlus size={14} />
            PPDB ONLINE SMAN 1 TOJO 2026/2027
          </div>
          <h2 className="text-5xl font-black text-white">Formulir <span className="text-gradient">Pendaftaran</span></h2>
          <p className="text-gray-400">Pastikan koordinat domisili Anda berada dalam radius zonasi 50 KM.</p>
        </div>
        <button onClick={() => setIsAdminView(true)} className="p-3 bg-white/5 border border-white/10 rounded-2xl text-gray-500 hover:text-blue-500 transition-all">
          <Settings size={20} />
        </button>
      </div>

      <div className="grid grid-cols-5 gap-2 mb-12">
        {[
          { icon: User, label: 'Diri' },
          { icon: MapPin, label: 'Alamat' },
          { icon: Users, label: 'Ortu' },
          { icon: BookOpen, label: 'Sekolah' },
          { icon: FileUp, label: 'Berkas' }
        ].map((item, i) => (
          <div key={i} className={`flex flex-col items-center gap-3 transition-all ${step === i + 1 ? 'scale-110 opacity-100' : 'opacity-30'}`}>
            <div className={`w-10 h-10 md:w-12 md:h-12 rounded-2xl flex items-center justify-center ${step === i + 1 ? 'bg-blue-600 text-white shadow-xl glow-blue' : 'bg-white/10 text-gray-400'}`}>
              <item.icon size={20} />
            </div>
            <span className="text-[8px] md:text-[10px] font-black uppercase tracking-widest text-white text-center">{item.label}</span>
          </div>
        ))}
      </div>

      <form onSubmit={handleSubmit} className="glass p-10 rounded-[3rem] border-white/10 space-y-12">
        {step === 1 && (
          <div className="space-y-8 animate-in slide-in-from-right-8 duration-500">
            <h3 className="text-2xl font-bold text-white flex items-center gap-3"><User className="text-blue-500" /> Identitas Calon Peserta Didik</h3>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Nama Lengkap</label>
                <input required name="namaLengkap" value={formData.namaLengkap} onChange={handleChange} className="w-full bg-white/5 border border-white/10 rounded-2xl p-4 text-white focus:border-blue-500 outline-none" />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest">NISN</label>
                <input required name="nisn" value={formData.nisn} onChange={handleChange} className="w-full bg-white/5 border border-white/10 rounded-2xl p-4 text-white" />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Jenis Kelamin</label>
                <select required name="jenisKelamin" value={formData.jenisKelamin} onChange={handleChange} className="w-full bg-white/5 border border-white/10 rounded-2xl p-4 text-gray-400 outline-none">
                  <option value="">Pilih...</option>
                  <option value="Laki-Laki">Laki-Laki</option>
                  <option value="Perempuan">Perempuan</option>
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Tanggal Lahir</label>
                <input required type="date" name="tanggalLahir" value={formData.tanggalLahir} onChange={handleChange} className="w-full bg-white/5 border border-white/10 rounded-2xl p-4 text-gray-400" />
              </div>
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-8 animate-in slide-in-from-right-8 duration-500">
            <h3 className="text-2xl font-bold text-white flex items-center gap-3"><MapPin className="text-blue-500" /> Domisili & Zonasi</h3>
            
            {/* Zonasi Check Block */}
            <div className={`p-8 rounded-[2rem] border-2 transition-all duration-500 ${distance ? (distance <= MAX_DISTANCE_KM ? 'bg-green-500/10 border-green-500/30' : 'bg-red-500/10 border-red-500/30') : 'bg-white/5 border-white/10'}`}>
               <div className="flex flex-col md:flex-row items-center justify-between gap-6">
                  <div className="space-y-2 text-center md:text-left">
                     <div className="flex items-center justify-center md:justify-start gap-2 text-white font-black uppercase text-xs tracking-widest">
                        <LocateFixed size={16} className="text-blue-500" />
                        Validasi Koordinat Zonasi
                     </div>
                     <p className="text-gray-400 text-xs">Radius Maksimal: <strong>50 KM</strong> dari SMAN 1 Tojo.</p>
                     {distance !== null && (
                        <div className={`text-xl font-black mt-2 ${distance <= MAX_DISTANCE_KM ? 'text-green-500' : 'text-red-500'}`}>
                           Jarak: {distance.toFixed(2)} KM
                           {distance <= MAX_DISTANCE_KM ? ' (Dalam Zonasi)' : ' (Luar Zonasi)'}
                        </div>
                     )}
                  </div>
                  <button 
                    type="button"
                    onClick={verifyLocation}
                    disabled={isLocating}
                    className="px-8 py-4 bg-blue-600 hover:bg-blue-500 text-white rounded-2xl font-black text-xs uppercase tracking-widest transition-all flex items-center gap-2 shadow-xl glow-blue disabled:opacity-50"
                  >
                    {isLocating ? <Navigation className="animate-spin" size={18} /> : <LocateFixed size={18} />}
                    {distance ? 'CEK ULANG LOKASI' : 'AMBIL KOORDINAT SAYA'}
                  </button>
               </div>
               
               {locationError && (
                  <div className="mt-6 p-4 bg-red-500/20 border border-red-500/30 rounded-xl flex items-center gap-3 text-red-400 text-xs animate-in slide-in-from-top-2">
                     <AlertTriangle size={18} /> {locationError}
                  </div>
               )}
            </div>

            <div className="grid md:grid-cols-3 gap-6">
               <div className="md:col-span-2 space-y-2">
                 <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Alamat Jalan</label>
                 <input required name="alamatJalan" value={formData.alamatJalan} onChange={handleChange} className="w-full bg-white/5 border border-white/10 rounded-2xl p-4 text-white" />
               </div>
               <div className="space-y-2">
                 <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Kecamatan</label>
                 <input required name="kecamatan" value={formData.kecamatan} onChange={handleChange} className="w-full bg-white/5 border border-white/10 rounded-2xl p-4 text-white" />
               </div>
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="space-y-8 animate-in slide-in-from-right-8 duration-500">
            <h3 className="text-2xl font-bold text-white flex items-center gap-3"><Users className="text-blue-500" /> Orang Tua Kandung</h3>
            <div className="grid md:grid-cols-2 gap-6">
                <input required placeholder="Nama Ayah" name="namaAyah" value={formData.namaAyah} onChange={handleChange} className="bg-white/5 border border-white/10 rounded-2xl p-4 text-white" />
                <input required placeholder="Nama Ibu" name="namaIbu" value={formData.namaIbu} onChange={handleChange} className="bg-white/5 border border-white/10 rounded-2xl p-4 text-white" />
            </div>
          </div>
        )}

        {step === 4 && (
          <div className="space-y-8 animate-in slide-in-from-right-8 duration-500">
             <h3 className="text-2xl font-bold text-white flex items-center gap-3"><BookOpen className="text-blue-500" /> Akademik</h3>
             <div className="grid md:grid-cols-2 gap-6">
               <input required placeholder="Sekolah Asal" name="sekolahAsal" value={formData.sekolahAsal} onChange={handleChange} className="bg-white/5 border border-white/10 rounded-2xl p-4 text-white" />
               <input required placeholder="Tahun Lulus" name="tahunLulus" value={formData.tahunLulus} onChange={handleChange} className="bg-white/5 border border-white/10 rounded-2xl p-4 text-white" />
             </div>
          </div>
        )}

        {step === 5 && (
          <div className="space-y-10 animate-in slide-in-from-right-8 duration-500">
            <h3 className="text-2xl font-bold text-white flex items-center gap-3"><FileUp className="text-blue-500" /> Berkas Digital</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
               <DocumentUploadBox title="Foto 3x4" field="fileFoto" icon={ImageIcon} />
               <DocumentUploadBox title="Kartu Keluarga (KK)" field="fileKK" icon={FileText} />
               <DocumentUploadBox title="Ijazah SMP" field="fileIjazah" icon={FileCheck} />
               <DocumentUploadBox title="Surat Ket. Lulus (SKL)" field="fileSKL" icon={FileText} />
               <DocumentUploadBox title="Kartu KIP" field="fileKIP" icon={CreditCard} required={false} />
            </div>
          </div>
        )}

        <div className="flex justify-between items-center pt-8 border-t border-white/5">
          {step > 1 ? (
            <button type="button" onClick={prevStep} className="px-8 py-4 bg-white/5 text-white rounded-2xl font-bold hover:bg-white/10 transition-all uppercase tracking-widest text-xs">Sebelumnya</button>
          ) : <div />}
          
          {step < 5 ? (
            <button type="button" onClick={nextStep} className="px-8 py-4 bg-blue-600 text-white rounded-2xl font-bold hover:bg-blue-500 transition-all uppercase tracking-widest text-xs flex items-center gap-2">Selanjutnya <ArrowRight size={18} /></button>
          ) : (
            <button type="submit" disabled={loading} className="px-10 py-4 bg-white text-black rounded-2xl font-black hover:bg-blue-600 hover:text-white transition-all uppercase tracking-widest text-xs flex items-center gap-2 glow-blue">
              {loading ? 'MENYIMPAN...' : <>KIRIM PENDAFTARAN <FileText size={18} /></>}
            </button>
          )}
        </div>
      </form>
    </section>
  );
};

export default PPDBSection;

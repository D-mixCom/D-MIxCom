
import React, { useState, useEffect } from 'react';
import { BookOpen, Upload, Send, User, Shield, CheckCircle, FileText, PlusCircle, UserCheck, Star, Clock, ArrowRight, LogOut, ChevronRight, Settings, Users, UserPlus, Trash2 } from 'lucide-react';
import { LearningMaterial, Assignment, Submission } from '../types';

// Initial Mock Data
const INITIAL_TEACHERS = [
  { id: 'GURU01', name: 'Bpk. Budi Santoso', subject: 'Matematika', classes: ['XI-IPA-1', 'XI-IPA-2'] },
  { id: 'GURU02', name: 'Ibu Siti Aminah', subject: 'Bahasa Inggris', classes: ['X-1', 'XII-IPA-1'] }
];

const INITIAL_STUDENTS: Record<string, any> = {
  '1234567801': { name: 'Ahmad Fauzi', class: 'XI-IPA-1' },
  '1234567802': { name: 'Siti Aminah', class: 'X-1' }
};

const ELearningSection: React.FC = () => {
  const [role, setRole] = useState<'student' | 'teacher' | 'admin' | null>(null);
  const [userId, setUserId] = useState('');
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [error, setError] = useState('');
  
  // App State (Simulated Database)
  const [allTeachers, setAllTeachers] = useState(INITIAL_TEACHERS);
  const [allStudents, setAllStudents] = useState(INITIAL_STUDENTS);
  const [materials, setMaterials] = useState<LearningMaterial[]>([]);
  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [submissions, setSubmissions] = useState<Submission[]>([]);

  // Admin Form States
  const [newTeacher, setNewTeacher] = useState({ id: '', name: '', subject: '', classes: '' });
  const [newStudent, setNewStudent] = useState({ nisn: '', name: '', class: '' });

  // Teacher Form States
  const [newMaterial, setNewMaterial] = useState({ title: '', targetClass: '', fileUrl: '' });
  const [newAssignment, setNewAssignment] = useState({ title: '', description: '', targetClass: '', deadline: '' });

  // Student Submission State
  const [activeAssignmentId, setActiveAssignmentId] = useState<string | null>(null);
  const [submissionContent, setSubmissionContent] = useState('');

  const handleLogin = () => {
    setError('');
    const id = userId.toUpperCase();

    if (role === 'admin') {
      if (id === 'ADMIN2026') {
        setCurrentUser({ name: 'Super Admin', role: 'admin' });
      } else {
        setError('ID Admin salah (Gunakan: ADMIN2026)');
      }
      return;
    }

    if (role === 'teacher') {
      const teacher = allTeachers.find(t => t.id === id);
      if (teacher) {
        setCurrentUser(teacher);
      } else {
        setError('ID Guru tidak ditemukan');
      }
    } else {
      const student = allStudents[userId];
      if (student) {
        setCurrentUser({ ...student, nisn: userId });
      } else {
        setError('NISN tidak terdaftar');
      }
    }
  };

  const logout = () => {
    setRole(null);
    setUserId('');
    setCurrentUser(null);
    setError('');
  };

  // --- ADMIN ACTIONS ---
  const addTeacher = () => {
    if (!newTeacher.id || !newTeacher.name) return;
    const teacherData = {
      ...newTeacher,
      id: newTeacher.id.toUpperCase(),
      classes: newTeacher.classes.split(',').map(c => c.trim())
    };
    setAllTeachers([...allTeachers, teacherData]);
    setNewTeacher({ id: '', name: '', subject: '', classes: '' });
  };

  const addStudent = () => {
    if (!newStudent.nisn || !newStudent.name) return;
    setAllStudents({
      ...allStudents,
      [newStudent.nisn]: { name: newStudent.name, class: newStudent.class }
    });
    setNewStudent({ nisn: '', name: '', class: '' });
  };

  const deleteTeacher = (id: string) => {
    setAllTeachers(allTeachers.filter(t => t.id !== id));
  };

  // --- TEACHER ACTIONS ---
  const uploadMaterial = () => {
    if (!newMaterial.title || !newMaterial.targetClass) return;
    const material: LearningMaterial = {
      id: Math.random().toString(36).substr(2, 9),
      title: newMaterial.title,
      teacherName: currentUser.name,
      subject: currentUser.subject,
      targetClass: newMaterial.targetClass,
      fileUrl: 'Simulated_File.pdf',
      timestamp: new Date().toLocaleString()
    };
    setMaterials([...materials, material]);
    setNewMaterial({ title: '', targetClass: '', fileUrl: '' });
  };

  const createAssignment = () => {
    if (!newAssignment.title || !newAssignment.targetClass) return;
    const assignment: Assignment = {
      id: Math.random().toString(36).substr(2, 9),
      title: newAssignment.title,
      description: newAssignment.description,
      teacherId: currentUser.id,
      teacherName: currentUser.name,
      subject: currentUser.subject,
      targetClass: newAssignment.targetClass,
      deadline: newAssignment.deadline
    };
    setAssignments([...assignments, assignment]);
    setNewAssignment({ title: '', description: '', targetClass: '', deadline: '' });
  };

  const giveGrade = (submissionId: string, grade: number, feedback: string) => {
    setSubmissions(submissions.map(s => 
      s.id === submissionId ? { ...s, grade, feedback, status: 'Graded' } : s
    ));
  };

  // --- STUDENT ACTIONS ---
  const submitAssignment = (assignmentId: string) => {
    const submission: Submission = {
      id: Math.random().toString(36).substr(2, 9),
      assignmentId,
      studentNisn: currentUser.nisn,
      studentName: currentUser.name,
      content: submissionContent,
      status: 'Pending',
      timestamp: new Date().toLocaleString()
    };
    setSubmissions([...submissions, submission]);
    setSubmissionContent('');
    setActiveAssignmentId(null);
  };

  if (!role) {
    return (
      <section className="py-24 max-w-5xl mx-auto px-4">
        <div className="text-center mb-16 space-y-4">
           <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-500 text-[10px] font-black uppercase tracking-[0.2em]">
            <BookOpen size={14} />
            Digital Learning Hub 2026
          </div>
          <h2 className="text-5xl font-black text-white">e-Learning <span className="text-gradient">SMAN 1 Tojo</span></h2>
          <p className="text-gray-400 text-lg">Pusat kendali pembelajaran digital terpadu.</p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8">
          <div onClick={() => setRole('student')} className="glass p-8 rounded-[3rem] hover:bg-blue-600/10 border-white/10 cursor-pointer transition-all group text-center space-y-4">
            <div className="w-16 h-16 bg-blue-600 rounded-2xl flex items-center justify-center mx-auto shadow-2xl group-hover:scale-110 transition-transform">
              <User size={32} className="text-white" />
            </div>
            <h3 className="text-xl font-bold text-white">Siswa</h3>
            <p className="text-gray-500 text-xs">Akses materi & tugas via NISN.</p>
          </div>
          
          <div onClick={() => setRole('teacher')} className="glass p-8 rounded-[3rem] hover:bg-purple-600/10 border-white/10 cursor-pointer transition-all group text-center space-y-4">
            <div className="w-16 h-16 bg-purple-600 rounded-2xl flex items-center justify-center mx-auto shadow-2xl group-hover:scale-110 transition-transform">
              <Shield size={32} className="text-white" />
            </div>
            <h3 className="text-xl font-bold text-white">Guru</h3>
            <p className="text-gray-500 text-xs">Kelola materi & berikan nilai.</p>
          </div>

          <div onClick={() => setRole('admin')} className="glass p-8 rounded-[3rem] hover:bg-yellow-600/10 border-white/10 cursor-pointer transition-all group text-center space-y-4">
            <div className="w-16 h-16 bg-yellow-600 rounded-2xl flex items-center justify-center mx-auto shadow-2xl group-hover:scale-110 transition-transform">
              <Settings size={32} className="text-white" />
            </div>
            <h3 className="text-xl font-bold text-white">Admin</h3>
            <p className="text-gray-500 text-xs">Kelola data Guru & Siswa.</p>
          </div>
        </div>
      </section>
    );
  }

  if (!currentUser) {
    return (
      <section className="py-24 max-w-md mx-auto px-4">
        <div className="glass p-10 rounded-[3rem] border-white/10 space-y-8 animate-in zoom-in duration-300">
          <div className="text-center">
            <h3 className="text-3xl font-black text-white">Login {role.toUpperCase()}</h3>
            <p className="text-gray-500 text-sm mt-2">Gunakan kredensial yang valid</p>
          </div>
          
          <div className="space-y-4">
            <div className="relative">
              <UserCheck className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" size={18} />
              <input 
                type="text" 
                placeholder={role === 'admin' ? 'ID Admin' : role === 'teacher' ? 'ID Guru' : 'NISN'}
                value={userId}
                onChange={(e) => setUserId(e.target.value)}
                className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 pl-12 pr-4 text-white focus:outline-none focus:border-blue-500 transition-all"
              />
            </div>
            {error && <p className="text-red-500 text-[10px] font-bold uppercase tracking-widest">{error}</p>}
            <button 
              onClick={handleLogin}
              className="w-full bg-blue-600 hover:bg-blue-500 text-white py-4 rounded-2xl font-black transition-all glow-blue"
            >
              KONFIRMASI LOGIN
            </button>
            <button onClick={() => setRole(null)} className="w-full text-gray-500 text-xs font-bold uppercase tracking-widest hover:text-white transition-colors">Batal</button>
          </div>
        </div>
      </section>
    );
  }

  // --- ADMIN VIEW ---
  if (role === 'admin') {
    return (
      <section className="py-12 max-w-7xl mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-12 gap-4">
          <div className="flex items-center gap-3 text-white">
            <div className="w-10 h-10 bg-yellow-600 rounded-xl flex items-center justify-center">
              <Settings size={20} />
            </div>
            <h2 className="text-3xl font-black">Admin Dashboard</h2>
          </div>
          <button onClick={logout} className="flex items-center gap-2 text-red-500 font-bold hover:bg-red-500/10 px-4 py-2 rounded-xl transition-all">
            <LogOut size={18} /> Logout
          </button>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Manage Teachers */}
          <div className="space-y-8">
            <div className="glass p-8 rounded-[2.5rem] border-white/10">
              <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-2"><UserPlus size={20} className="text-purple-500" /> Tambah Data Guru</h3>
              <div className="grid grid-cols-2 gap-4">
                <input 
                  placeholder="ID Guru (GURU03)"
                  value={newTeacher.id}
                  onChange={e => setNewTeacher({...newTeacher, id: e.target.value})}
                  className="bg-white/5 border border-white/10 rounded-xl p-3 text-xs text-white"
                />
                <input 
                  placeholder="Nama Lengkap"
                  value={newTeacher.name}
                  onChange={e => setNewTeacher({...newTeacher, name: e.target.value})}
                  className="bg-white/5 border border-white/10 rounded-xl p-3 text-xs text-white"
                />
                <input 
                  placeholder="Mata Pelajaran"
                  value={newTeacher.subject}
                  onChange={e => setNewTeacher({...newTeacher, subject: e.target.value})}
                  className="bg-white/5 border border-white/10 rounded-xl p-3 text-xs text-white"
                />
                <input 
                  placeholder="Kelas (Pisah koma: X-1, XI-IPA)"
                  value={newTeacher.classes}
                  onChange={e => setNewTeacher({...newTeacher, classes: e.target.value})}
                  className="bg-white/5 border border-white/10 rounded-xl p-3 text-xs text-white"
                />
                <button 
                  onClick={addTeacher}
                  className="col-span-2 bg-purple-600 hover:bg-purple-500 text-white py-3 rounded-xl font-black text-xs transition-all"
                >
                  SIMPAN DATA GURU
                </button>
              </div>
            </div>

            <div className="glass p-8 rounded-[2.5rem] border-white/10">
              <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-2"><Users size={20} /> Daftar Guru Terdaftar</h3>
              <div className="space-y-3">
                {allTeachers.map(t => (
                  <div key={t.id} className="p-4 bg-white/5 border border-white/5 rounded-2xl flex items-center justify-between">
                    <div>
                      <p className="text-sm font-bold text-white">{t.name}</p>
                      <p className="text-[10px] text-gray-500 uppercase tracking-widest">{t.id} • {t.subject}</p>
                    </div>
                    <button onClick={() => deleteTeacher(t.id)} className="text-red-500 hover:bg-red-500/10 p-2 rounded-lg transition-all">
                      <Trash2 size={16} />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Manage Students */}
          <div className="space-y-8">
            <div className="glass p-8 rounded-[2.5rem] border-white/10">
              <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-2"><UserPlus size={20} className="text-blue-500" /> Tambah Data Siswa</h3>
              <div className="grid grid-cols-2 gap-4">
                <input 
                  placeholder="NISN"
                  value={newStudent.nisn}
                  onChange={e => setNewStudent({...newStudent, nisn: e.target.value})}
                  className="bg-white/5 border border-white/10 rounded-xl p-3 text-xs text-white"
                />
                <input 
                  placeholder="Nama Siswa"
                  value={newStudent.name}
                  onChange={e => setNewStudent({...newStudent, name: e.target.value})}
                  className="bg-white/5 border border-white/10 rounded-xl p-3 text-xs text-white"
                />
                <select 
                  value={newStudent.class}
                  onChange={e => setNewStudent({...newStudent, class: e.target.value})}
                  className="bg-white/5 border border-white/10 rounded-xl p-3 text-xs text-gray-400"
                >
                  <option value="">Pilih Kelas</option>
                  <option value="X-1">X-1</option>
                  <option value="X-2">X-2</option>
                  <option value="XI-IPA-1">XI-IPA-1</option>
                  <option value="XI-IPA-2">XI-IPA-2</option>
                  <option value="XII-IPA-1">XII-IPA-1</option>
                </select>
                <button 
                  onClick={addStudent}
                  className="bg-blue-600 hover:bg-blue-500 text-white py-3 rounded-xl font-black text-xs transition-all"
                >
                  SIMPAN DATA SISWA
                </button>
              </div>
            </div>

            <div className="glass p-8 rounded-[2.5rem] border-white/10">
              <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-2"><Users size={20} /> Siswa Terbaru</h3>
              <div className="space-y-3">
                {Object.entries(allStudents).slice(-5).reverse().map(([nisn, s]: any) => (
                  <div key={nisn} className="p-4 bg-white/5 border border-white/5 rounded-2xl flex items-center justify-between">
                    <div>
                      <p className="text-sm font-bold text-white">{s.name}</p>
                      <p className="text-[10px] text-gray-500 uppercase tracking-widest">{nisn} • Kelas {s.class}</p>
                    </div>
                    <div className="px-2 py-1 bg-green-500/10 text-green-500 text-[8px] font-black rounded uppercase">Aktif</div>
                  </div>
                ))}
                {Object.keys(allStudents).length > 5 && (
                  <p className="text-center text-[10px] text-gray-600 font-bold uppercase py-2">Dan {Object.keys(allStudents).length - 5} siswa lainnya...</p>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>
    );
  }

  // --- TEACHER VIEW ---
  if (role === 'teacher') {
    return (
      <section className="py-12 max-w-7xl mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-12 gap-4">
          <div>
            <div className="flex items-center gap-3 text-white mb-2">
               <div className="w-10 h-10 bg-purple-600 rounded-xl flex items-center justify-center">
                <Shield size={20} />
              </div>
              <h2 className="text-3xl font-black">{currentUser.name}</h2>
            </div>
            <div className="flex gap-2">
              <span className="px-3 py-1 bg-purple-600/20 text-purple-400 text-[10px] font-bold rounded-lg border border-purple-600/20 uppercase tracking-widest">Guru {currentUser.subject}</span>
              <span className="px-3 py-1 bg-white/5 text-gray-400 text-[10px] font-bold rounded-lg border border-white/10 uppercase tracking-widest">{currentUser.id}</span>
            </div>
          </div>
          <button onClick={logout} className="flex items-center gap-2 text-red-500 font-bold hover:bg-red-500/10 px-4 py-2 rounded-xl transition-all">
            <LogOut size={18} /> Logout
          </button>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Sidebar: Submissions to Grade */}
          <div className="lg:col-span-1 space-y-6">
            <div className="glass p-8 rounded-[2.5rem] border-white/10">
              <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-2"><Clock size={20} className="text-yellow-500" /> Tugas Masuk</h3>
              <div className="space-y-4">
                {submissions.filter(s => s.status === 'Pending').length === 0 ? (
                  <p className="text-gray-500 text-xs italic">Belum ada tugas masuk.</p>
                ) : (
                  submissions.filter(s => s.status === 'Pending').map(s => (
                    <div key={s.id} className="p-4 bg-white/5 border border-white/5 rounded-2xl space-y-3">
                      <div className="flex justify-between items-start">
                        <span className="text-xs font-bold text-white">{s.studentName}</span>
                        <span className="text-[8px] text-gray-500">{s.timestamp}</span>
                      </div>
                      <p className="text-[10px] text-gray-400 line-clamp-2 italic">"{s.content}"</p>
                      <div className="flex gap-2">
                        <input 
                          type="number" 
                          placeholder="Nilai" 
                          className="w-16 bg-white/10 border border-white/10 rounded-lg p-1.5 text-xs text-center text-white"
                          id={`grade-${s.id}`}
                        />
                        <button 
                          onClick={() => {
                            const grade = (document.getElementById(`grade-${s.id}`) as HTMLInputElement).value;
                            if(grade) giveGrade(s.id, parseInt(grade), 'Pekerjaan yang baik!');
                          }}
                          className="flex-1 bg-blue-600 hover:bg-blue-500 text-white text-[10px] font-black rounded-lg py-1.5 transition-all"
                        >
                          BERI NILAI
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>

          <div className="lg:col-span-2 space-y-8">
            <div className="grid md:grid-cols-2 gap-8">
              <div className="glass p-8 rounded-[2.5rem] border-white/10 space-y-6">
                <h3 className="text-xl font-bold text-white flex items-center gap-2"><PlusCircle size={20} className="text-blue-500" /> Unggah Materi</h3>
                <div className="space-y-4">
                  <input 
                    type="text" 
                    placeholder="Judul Materi" 
                    value={newMaterial.title}
                    onChange={e => setNewMaterial({...newMaterial, title: e.target.value})}
                    className="w-full bg-white/5 border border-white/10 rounded-xl p-4 text-xs text-white"
                  />
                  <select 
                    value={newMaterial.targetClass}
                    onChange={e => setNewMaterial({...newMaterial, targetClass: e.target.value})}
                    className="w-full bg-white/5 border border-white/10 rounded-xl p-4 text-xs text-gray-400"
                  >
                    <option value="">Pilih Kelas</option>
                    {currentUser.classes?.map((c: string) => <option key={c} value={c}>{c}</option>)}
                  </select>
                  <button onClick={uploadMaterial} className="w-full bg-white text-black py-4 rounded-xl font-black text-xs hover:bg-blue-600 hover:text-white transition-all flex items-center justify-center gap-2">
                    <Upload size={16} /> UNGGAH MEDIA
                  </button>
                </div>
              </div>

              <div className="glass p-8 rounded-[2.5rem] border-white/10 space-y-6">
                <h3 className="text-xl font-bold text-white flex items-center gap-2"><FileText size={20} className="text-green-500" /> Buat Tugas</h3>
                <div className="space-y-4">
                  <input 
                    type="text" 
                    placeholder="Judul Tugas" 
                    value={newAssignment.title}
                    onChange={e => setNewAssignment({...newAssignment, title: e.target.value})}
                    className="w-full bg-white/5 border border-white/10 rounded-xl p-4 text-xs text-white"
                  />
                  <textarea 
                    placeholder="Instruksi Tugas..." 
                    value={newAssignment.description}
                    onChange={e => setNewAssignment({...newAssignment, description: e.target.value})}
                    className="w-full bg-white/5 border border-white/10 rounded-xl p-4 text-xs text-white h-20"
                  />
                   <select 
                    value={newAssignment.targetClass}
                    onChange={e => setNewAssignment({...newAssignment, targetClass: e.target.value})}
                    className="w-full bg-white/5 border border-white/10 rounded-xl p-4 text-xs text-gray-400"
                  >
                    <option value="">Pilih Kelas</option>
                    {currentUser.classes?.map((c: string) => <option key={c} value={c}>{c}</option>)}
                  </select>
                  <button onClick={createAssignment} className="w-full bg-green-600 hover:bg-green-500 text-white py-4 rounded-xl font-black text-xs transition-all flex items-center justify-center gap-2">
                    <Send size={16} /> PUBLIKASIKAN TUGAS
                  </button>
                </div>
              </div>
            </div>

            <div className="glass p-10 rounded-[2.5rem] border-white/10">
              <h3 className="text-2xl font-bold text-white mb-8">Riwayat Konten</h3>
              <div className="space-y-4">
                {[...materials, ...assignments].length === 0 ? (
                   <div className="py-12 text-center text-gray-500">Belum ada konten.</div>
                ) : (
                  [...materials, ...assignments].map((item: any) => (
                    <div key={item.id} className="p-6 bg-white/5 border border-white/5 rounded-3xl flex items-center justify-between group hover:bg-white/10 transition-all">
                      <div className="flex items-center gap-4">
                        <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${'fileUrl' in item ? 'bg-blue-600/20 text-blue-500' : 'bg-green-600/20 text-green-500'}`}>
                          {'fileUrl' in item ? <BookOpen size={24} /> : <FileText size={24} />}
                        </div>
                        <div>
                          <h4 className="font-bold text-white">{item.title}</h4>
                          <span className="text-[10px] text-gray-500 uppercase font-black tracking-widest">{item.targetClass} • {'fileUrl' in item ? 'MATERI' : 'TUGAS'}</span>
                        </div>
                      </div>
                      <ChevronRight className="text-gray-500 group-hover:text-white transition-all" />
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      </section>
    );
  }

  // --- STUDENT VIEW ---
  return (
    <section className="py-12 max-w-7xl mx-auto px-4">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-12 gap-4">
        <div className="space-y-2">
          <div className="flex items-center gap-3 text-white">
             <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center">
              <User size={20} />
            </div>
            <h2 className="text-3xl font-black">{currentUser.name}</h2>
          </div>
          <div className="flex gap-2">
             <span className="px-3 py-1 bg-blue-600/20 text-blue-400 text-[10px] font-bold rounded-lg border border-blue-600/20 uppercase tracking-widest">Kelas {currentUser.class}</span>
             <span className="px-3 py-1 bg-white/5 text-gray-400 text-[10px] font-bold rounded-lg border border-white/10 uppercase tracking-widest">NISN: {currentUser.nisn}</span>
          </div>
        </div>
        <button onClick={logout} className="flex items-center gap-2 text-red-500 font-bold hover:bg-red-500/10 px-4 py-2 rounded-xl transition-all">
          <LogOut size={18} /> Logout
        </button>
      </div>

      <div className="grid lg:grid-cols-12 gap-12">
        <div className="lg:col-span-4 space-y-6">
           <div className="glass p-8 rounded-[2.5rem] border-white/10">
              <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-2"><Star size={20} className="text-yellow-500" /> Nilai Saya</h3>
              <div className="space-y-4">
                {submissions.filter(s => s.studentNisn === currentUser.nisn && s.status === 'Graded').length === 0 ? (
                  <p className="text-gray-500 text-xs italic text-center py-4">Belum ada tugas dinilai.</p>
                ) : (
                  submissions.filter(s => s.studentNisn === currentUser.nisn && s.status === 'Graded').map(s => (
                    <div key={s.id} className="p-4 bg-green-500/10 border border-green-500/20 rounded-2xl flex items-center justify-between">
                      <div>
                        <h4 className="text-xs font-bold text-white uppercase truncate max-w-[120px]">Tugas ID: {s.assignmentId}</h4>
                        <p className="text-[10px] text-gray-500">Feedback: {s.feedback}</p>
                      </div>
                      <div className="text-2xl font-black text-green-500">{s.grade}</div>
                    </div>
                  ))
                )}
              </div>
           </div>
        </div>

        <div className="lg:col-span-8 space-y-12">
           <div className="space-y-6">
              <h3 className="text-2xl font-black text-white px-2">Media Pembelajaran</h3>
              <div className="grid md:grid-cols-2 gap-6">
                {materials.filter(m => m.targetClass === currentUser.class).length === 0 ? (
                  <div className="col-span-2 glass p-8 rounded-[2rem] text-center text-gray-500 text-sm">Tidak ada materi kelas Anda.</div>
                ) : (
                  materials.filter(m => m.targetClass === currentUser.class).map(m => (
                    <div key={m.id} className="glass p-6 rounded-[2rem] border-white/10 hover:bg-white/5 transition-all group">
                      <div className="flex items-center gap-4 mb-4">
                        <div className="w-12 h-12 bg-blue-600 rounded-2xl flex items-center justify-center text-white shadow-lg">
                          <BookOpen size={24} />
                        </div>
                        <div>
                          <h4 className="font-bold text-white group-hover:text-blue-400 transition-colors">{m.title}</h4>
                          <p className="text-[10px] text-gray-500 uppercase font-black">{m.subject}</p>
                        </div>
                      </div>
                      <div className="flex justify-between items-center pt-4 border-t border-white/5">
                        <span className="text-[9px] text-gray-500 font-bold uppercase">{m.teacherName}</span>
                        <button className="text-[10px] font-black text-blue-500 flex items-center gap-1 hover:underline">UNDUH <ChevronRight size={14}/></button>
                      </div>
                    </div>
                  ))
                )}
              </div>
           </div>

           <div className="space-y-6">
              <h3 className="text-2xl font-black text-white px-2">Daftar Tugas</h3>
              <div className="space-y-4">
                {assignments.filter(a => a.targetClass === currentUser.class).length === 0 ? (
                  <div className="glass p-8 rounded-[2rem] text-center text-gray-500 text-sm">Belum ada tugas aktif.</div>
                ) : (
                  assignments.filter(a => a.targetClass === currentUser.class).map(a => {
                    const hasSubmitted = submissions.find(s => s.assignmentId === a.id && s.studentNisn === currentUser.nisn);
                    return (
                      <div key={a.id} className={`glass p-8 rounded-[2.5rem] border-white/10 transition-all ${activeAssignmentId === a.id ? 'ring-2 ring-blue-600' : ''}`}>
                        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
                          <div>
                            <h4 className="text-xl font-bold text-white">{a.title}</h4>
                            <p className="text-xs text-blue-500 font-bold uppercase tracking-widest mt-1">{a.subject} • {a.teacherName}</p>
                          </div>
                          {hasSubmitted ? (
                            <div className="flex items-center gap-2 text-green-500 text-xs font-black uppercase tracking-widest">
                              <CheckCircle size={18} /> TERKIRIM
                            </div>
                          ) : (
                             <button 
                              onClick={() => setActiveAssignmentId(a.id)}
                              className="px-6 py-2 bg-white text-black text-[10px] font-black rounded-xl hover:bg-blue-600 hover:text-white transition-all uppercase tracking-widest"
                            >
                              KERJAKAN
                            </button>
                          )}
                        </div>
                        <p className="text-gray-400 text-sm mb-6 leading-relaxed">{a.description}</p>
                        {activeAssignmentId === a.id && !hasSubmitted && (
                          <div className="space-y-4 animate-in slide-in-from-top-4 duration-300 bg-white/5 p-6 rounded-3xl border border-white/5">
                            <textarea 
                              placeholder="Ketik jawaban..."
                              value={submissionContent}
                              onChange={e => setSubmissionContent(e.target.value)}
                              className="w-full bg-white/5 border border-white/10 rounded-2xl p-4 text-xs text-white h-32 focus:outline-none focus:border-blue-500"
                            />
                            <div className="flex gap-3">
                              <button onClick={() => submitAssignment(a.id)} className="flex-1 bg-blue-600 text-white py-3 rounded-xl text-xs font-black transition-all">KIRIM</button>
                              <button onClick={() => setActiveAssignmentId(null)} className="px-6 text-gray-500 hover:text-white text-xs font-bold uppercase">Batal</button>
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })
                )}
              </div>
           </div>
        </div>
      </div>
    </section>
  );
};

export default ELearningSection;

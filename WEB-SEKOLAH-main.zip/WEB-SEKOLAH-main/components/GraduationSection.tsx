
import React, { useState, useRef, useEffect } from 'react';
import { Search, Award, Info, CheckCircle, XCircle, Sparkles, BookOpen, ArrowRight, Settings, LogIn, UserPlus, FileSpreadsheet, Download, Trash2, X, Plus, Upload, Lock, Clock, CalendarClock } from 'lucide-react';
import { GraduationStatus } from '../types';

// Default Target Date if not set in localStorage
const DEFAULT_TARGET_DATE = new Date('2026-06-15T10:00:00').getTime();

const INITIAL_GRADUATION_DATA: Record<string, GraduationStatus> = {
  '1234567801': {
    name: 'Ahmad Fauzi',
    nisn: '1234567801',
    status: 'LULUS',
    message: 'Selamat! Anda dinyatakan LULUS dari SMAN 1 Tojo dengan predikat Memuaskan.',
    quote: 'Masa depan adalah milik mereka yang percaya pada keindahan mimpi mereka. Teruslah terbang tinggi!'
  },
  '1234567802': {
    name: 'Siti Aminah',
    nisn: '1234567802',
    status: 'LULUS',
    message: 'Selamat! Anda dinyatakan LULUS dari SMAN 1 Tojo. Prestasi Anda membanggakan sekolah.',
    quote: 'Keberhasilan bukanlah akhir, kegagalan bukanlah fatal: keberanian untuk melanjutkanlah yang terpenting.'
  }
};

const GraduationSection: React.FC = () => {
  const [nisn, setNisn] = useState('');
  const [result, setResult] = useState<GraduationStatus | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // Target Date State (Loaded from localStorage)
  const [targetDate, setTargetDate] = useState<number>(() => {
    const saved = localStorage.getItem('graduation_target_date');
    return saved ? parseInt(saved) : DEFAULT_TARGET_DATE;
  });

  // Countdown State
  const [timeLeft, setTimeLeft] = useState<{days: number, hours: number, minutes: number, seconds: number} | null>(null);
  const [isLocked, setIsLocked] = useState(true);

  // Admin States
  const [isAdminMode, setIsAdminMode] = useState(false);
  const [adminAuth, setAdminAuth] = useState(false);
  const [adminPassword, setAdminPassword] = useState('');
  const [students, setStudents] = useState<Record<string, GraduationStatus>>(INITIAL_GRADUATION_DATA);
  const [newStudent, setNewStudent] = useState<GraduationStatus>({
    name: '',
    nisn: '',
    status: 'LULUS',
    message: '',
    quote: ''
  });
  
  // Admin Date Setting State
  const [tempDate, setTempDate] = useState(() => {
    const d = new Date(targetDate);
    // Format to yyyy-MM-ddThh:mm for datetime-local input
    return d.toISOString().slice(0, 16);
  });

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Countdown Logic
  useEffect(() => {
    const timer = setInterval(() => {
      const now = new Date().getTime();
      const distance = targetDate - now;

      if (distance < 0) {
        clearInterval(timer);
        setIsLocked(false);
        setTimeLeft(null);
      } else {
        setIsLocked(true);
        setTimeLeft({
          days: Math.floor(distance / (1000 * 60 * 60 * 24)),
          hours: Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
          minutes: Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60)),
          seconds: Math.floor((distance % (1000 * 60)) / 1000)
        });
      }
    }, 1000);

    return () => clearInterval(timer);
  }, [targetDate]);

  const handleSearch = () => {
    if (isLocked) return;
    if (!nisn) {
      setError('Harap masukkan NISN Anda.');
      return;
    }
    setLoading(true);
    setError('');
    setResult(null);
    
    setTimeout(() => {
      const student = students[nisn];
      if (student) {
        setResult(student);
      } else {
        setError('Data NISN tidak ditemukan. Pastikan nomor yang Anda masukkan benar.');
      }
      setLoading(false);
    }, 1500);
  };

  const handleAdminLogin = () => {
    if (adminPassword === 'ADMIN2026') {
      setAdminAuth(true);
      setError('');
    } else {
      setError('Password Admin Salah (Hint: ADMIN2026)');
    }
  };

  const handleSaveTargetDate = () => {
    const newTarget = new Date(tempDate).getTime();
    if (isNaN(newTarget)) {
      alert("Format tanggal tidak valid.");
      return;
    }
    setTargetDate(newTarget);
    localStorage.setItem('graduation_target_date', newTarget.toString());
    alert("Waktu pengumuman berhasil diperbarui!");
  };

  const handleAddManual = () => {
    if (!newStudent.nisn || !newStudent.name) return;
    setStudents(prev => ({
      ...prev,
      [newStudent.nisn]: newStudent
    }));
    setNewStudent({ name: '', nisn: '', status: 'LULUS', message: '', quote: '' });
    alert(`Data ${newStudent.name} berhasil ditambahkan!`);
  };

  const handleDelete = (id: string) => {
    const newStudents = { ...students };
    delete newStudents[id];
    setStudents(newStudents);
  };

  const downloadTemplate = () => {
    const csvContent = "nisn,name,status,message,quote\n1234567810,Nama Contoh,LULUS,Selamat kamu lulus,Teruslah berjuang";
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'template_kelulusan_sman1tojo.csv';
    a.click();
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      const lines = text.split('\n');
      const newEntries: Record<string, GraduationStatus> = {};

      for (let i = 1; i < lines.length; i++) {
        const columns = lines[i].split(',');
        if (columns.length >= 5) {
          const [nisn, name, status, message, quote] = columns.map(c => c.trim());
          if (nisn && name) {
            newEntries[nisn] = {
              nisn, name, status: (status.toUpperCase() === 'LULUS' ? 'LULUS' : 'TIDAK LULUS'),
              message, quote
            };
          }
        }
      }
      setStudents(prev => ({ ...prev, ...newEntries }));
      alert(`Berhasil mengunggah ${Object.keys(newEntries).length} data siswa.`);
    };
    reader.readAsText(file);
  };

  if (isAdminMode && !adminAuth) {
    return (
      <section className="py-24 max-w-md mx-auto px-4">
        <div className="glass p-10 rounded-[3rem] border-white/10 space-y-8 animate-in zoom-in duration-300">
          <div className="text-center">
            <Settings className="mx-auto text-blue-500 mb-4" size={40} />
            <h3 className="text-3xl font-black text-white">Admin Access</h3>
            <p className="text-gray-500 text-sm mt-2">Kelola Database Kelulusan</p>
          </div>
          <div className="space-y-4">
            <input 
              type="password" 
              placeholder="Admin Password"
              value={adminPassword}
              onChange={(e) => setAdminPassword(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 px-6 text-white focus:outline-none focus:border-blue-500 transition-all"
            />
            {error && <p className="text-red-500 text-[10px] font-bold uppercase tracking-widest">{error}</p>}
            <button 
              onClick={handleAdminLogin}
              className="w-full bg-blue-600 hover:bg-blue-500 text-white py-4 rounded-2xl font-black transition-all glow-blue"
            >
              LOG IN
            </button>
            <button onClick={() => setIsAdminMode(false)} className="w-full text-gray-500 text-xs font-bold uppercase tracking-widest hover:text-white transition-colors">Batal</button>
          </div>
        </div>
      </section>
    );
  }

  if (isAdminMode && adminAuth) {
    return (
      <section className="py-12 max-w-6xl mx-auto px-4">
        <div className="flex justify-between items-center mb-12">
          <h2 className="text-3xl font-black text-white flex items-center gap-3">
            <Settings className="text-blue-500" /> Control Panel Kelulusan
          </h2>
          <button onClick={() => { setAdminAuth(false); setIsAdminMode(false); }} className="flex items-center gap-2 text-red-500 font-bold hover:bg-red-500/10 px-4 py-2 rounded-xl transition-all">
            Keluar Panel
          </button>
        </div>

        <div className="grid lg:grid-cols-2 gap-8 mb-12">
          {/* Announcement Timing Control */}
          <div className="glass p-8 rounded-[2.5rem] border-white/10 space-y-6">
            <h3 className="text-xl font-bold text-white flex items-center gap-2"><CalendarClock size={20} className="text-yellow-500" /> Pengaturan Waktu</h3>
            <div className="space-y-4">
              <p className="text-gray-500 text-xs">Atur kapan sistem pengumuman akan dibuka secara otomatis untuk siswa.</p>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Waktu Pengumuman (WITA)</label>
                <input 
                  type="datetime-local"
                  value={tempDate}
                  onChange={(e) => setTempDate(e.target.value)}
                  className="w-full bg-white/5 border border-white/10 rounded-xl p-4 text-white focus:border-yellow-500 outline-none transition-all"
                />
              </div>
              <button 
                onClick={handleSaveTargetDate}
                className="w-full bg-yellow-600 hover:bg-yellow-500 text-white py-4 rounded-xl font-black transition-all flex items-center justify-center gap-2"
              >
                UPDATE JADWAL PENGUMUMAN
              </button>
            </div>
          </div>

          <div className="glass p-8 rounded-[2.5rem] border-white/10 space-y-6">
            <h3 className="text-xl font-bold text-white flex items-center gap-2"><FileSpreadsheet size={20} className="text-green-500" /> Bulk Upload (CSV)</h3>
            <p className="text-gray-500 text-xs">Gunakan format CSV untuk menambahkan banyak data sekaligus secara otomatis.</p>
            <div className="flex flex-col gap-4">
              <button 
                onClick={downloadTemplate}
                className="w-full bg-white/5 border border-white/10 hover:bg-white/10 text-white py-4 rounded-xl font-bold text-sm flex items-center justify-center gap-2 transition-all"
              >
                <Download size={18} /> UNDUH TEMPLATE .CSV
              </button>
              <div 
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-white/10 rounded-2xl py-10 flex flex-col items-center justify-center gap-3 cursor-pointer hover:border-green-500/50 hover:bg-green-500/5 transition-all group"
              >
                <Upload className="text-gray-500 group-hover:text-green-500 transition-colors" size={32} />
                <span className="text-sm font-bold text-gray-500 uppercase tracking-widest">Pilih File CSV</span>
                <input type="file" ref={fileInputRef} onChange={handleFileUpload} className="hidden" accept=".csv" />
              </div>
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          <div className="glass p-8 rounded-[2.5rem] border-white/10 space-y-6">
            <h3 className="text-xl font-bold text-white flex items-center gap-2"><UserPlus size={20} className="text-blue-500" /> Input Manual</h3>
            <div className="grid gap-4">
              <input 
                placeholder="Nama Lengkap"
                value={newStudent.name}
                onChange={e => setNewStudent({...newStudent, name: e.target.value})}
                className="bg-white/5 border border-white/10 rounded-xl p-4 text-sm text-white"
              />
              <div className="grid grid-cols-2 gap-4">
                <input 
                  placeholder="NISN"
                  value={newStudent.nisn}
                  onChange={e => setNewStudent({...newStudent, nisn: e.target.value})}
                  className="bg-white/5 border border-white/10 rounded-xl p-4 text-sm text-white"
                />
                <select 
                  value={newStudent.status}
                  onChange={e => setNewStudent({...newStudent, status: e.target.value as any})}
                  className="bg-white/5 border border-white/10 rounded-xl p-4 text-sm text-gray-400"
                >
                  <option value="LULUS">LULUS</option>
                  <option value="TIDAK LULUS">TIDAK LULUS</option>
                </select>
              </div>
              <textarea 
                placeholder="Pesan Resmi Kelulusan"
                value={newStudent.message}
                onChange={e => setNewStudent({...newStudent, message: e.target.value})}
                className="bg-white/5 border border-white/10 rounded-xl p-4 text-sm text-white h-24"
              />
              <textarea 
                placeholder="Quote Motivasi"
                value={newStudent.quote}
                onChange={e => setNewStudent({...newStudent, quote: e.target.value})}
                className="bg-white/5 border border-white/10 rounded-xl p-4 text-sm text-white h-20"
              />
              <button 
                onClick={handleAddManual}
                className="bg-blue-600 hover:bg-blue-500 text-white py-4 rounded-xl font-black transition-all flex items-center justify-center gap-2"
              >
                <Plus size={18} /> SIMPAN DATA SISWA
              </button>
            </div>
          </div>

          <div className="glass p-8 rounded-[2.5rem] border-white/10 max-h-[500px] overflow-y-auto">
            <h3 className="text-lg font-bold text-white mb-4">Database Terdaftar ({Object.keys(students).length})</h3>
            <div className="space-y-2">
              {Object.values(students).map(s => (
                <div key={s.nisn} className="flex items-center justify-between p-3 bg-white/5 rounded-xl border border-white/5">
                  <div>
                    <p className="text-xs font-bold text-white">{s.name}</p>
                    <p className="text-[10px] text-gray-500">{s.nisn} • {s.status}</p>
                  </div>
                  <button onClick={() => handleDelete(s.nisn)} className="text-red-500 hover:bg-red-500/10 p-2 rounded-lg transition-all">
                    <Trash2 size={14} />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="py-12 pb-24 relative overflow-hidden">
      <div className="absolute top-1/2 left-0 w-64 h-64 bg-yellow-500/5 rounded-full blur-[100px] pointer-events-none"></div>
      
      <div className="max-w-4xl mx-auto px-4 relative z-10">
        <div className="flex justify-center mb-8">
           <button 
             onClick={() => setIsAdminMode(true)}
             className="flex items-center gap-2 px-5 py-2 rounded-full glass border-white/10 hover:bg-blue-600/20 hover:border-blue-500/50 text-[11px] font-black text-gray-400 hover:text-white transition-all uppercase tracking-widest"
           >
             <Settings size={14} /> Panel Admin Kelulusan
           </button>
        </div>

        <div className="text-center mb-12 space-y-4">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-yellow-500/10 border border-yellow-500/20 text-yellow-500 text-[10px] font-black uppercase tracking-[0.2em]">
            <Award size={14} className="animate-pulse" />
            E-Announcement System 2026
          </div>
          <h2 className="text-4xl md:text-6xl font-black leading-tight">
            Gerbang <span className="text-gradient">Kelulusan</span>
          </h2>
          <p className="text-gray-400 max-w-xl mx-auto text-lg font-medium">
            Momen bersejarah Anda dimulai di sini. Masukkan NISN untuk mengakses lembar hasil studi akhir.
          </p>
        </div>

        {/* Countdown Timer Display */}
        {isLocked && timeLeft && (
          <div className="mb-12 animate-in fade-in slide-in-from-top-4 duration-700">
            <div className="glass p-10 rounded-[3rem] border-blue-500/20 shadow-[0_0_50px_-12px_rgba(59,130,246,0.2)] text-center space-y-8 relative overflow-hidden">
               <div className="absolute inset-0 bg-blue-600/5 pointer-events-none"></div>
               <div className="relative z-10">
                 <div className="flex items-center justify-center gap-3 mb-6 text-blue-400">
                    <Clock size={24} className="animate-spin [animation-duration:10s]" />
                    <span className="text-xs font-black uppercase tracking-[0.4em]">Akses Terkunci Hingga:</span>
                 </div>
                 
                 <div className="grid grid-cols-4 gap-4 md:gap-8 max-w-2xl mx-auto">
                    {[
                      { value: timeLeft.days, label: 'Hari' },
                      { value: timeLeft.hours, label: 'Jam' },
                      { value: timeLeft.minutes, label: 'Menit' },
                      { value: timeLeft.seconds, label: 'Detik' }
                    ].map((unit, i) => (
                      <div key={i} className="space-y-2">
                        <div className="glass h-20 md:h-28 rounded-3xl flex items-center justify-center border-white/10">
                          <span className="text-3xl md:text-5xl font-black text-white tabular-nums">{unit.value.toString().padStart(2, '0')}</span>
                        </div>
                        <span className="text-[10px] md:text-[11px] font-black text-gray-500 uppercase tracking-widest">{unit.label}</span>
                      </div>
                    ))}
                 </div>

                 <div className="mt-10 flex flex-col items-center gap-3">
                    <div className="flex items-center gap-2 px-6 py-2 bg-red-500/10 border border-red-500/20 rounded-full text-red-500">
                       <Lock size={14} />
                       <span className="text-[10px] font-black uppercase tracking-widest">Sistem Pengumuman Masih Terkunci</span>
                    </div>
                    <p className="text-xs text-gray-500 font-medium">Pengumuman kelulusan akan dibuka secara serentak di seluruh wilayah Tojo Una-Una sesuai jadwal yang ditetapkan.</p>
                 </div>
               </div>
            </div>
          </div>
        )}

        <div className={`glass p-8 md:p-14 rounded-[3rem] shadow-2xl border-white/10 relative overflow-hidden group transition-all duration-500 ${isLocked ? 'opacity-40 grayscale pointer-events-none scale-[0.98]' : 'opacity-100'}`}>
          <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/5 rounded-full blur-3xl group-hover:bg-blue-500/10 transition-all duration-700"></div>
          
          <div className="flex flex-col md:flex-row gap-4 mb-10">
            <div className="relative flex-1">
              <Search className="absolute left-5 top-1/2 -translate-y-1/2 text-gray-500 group-focus-within:text-blue-500 transition-colors" size={22} />
              <input 
                type="text" 
                disabled={isLocked}
                value={nisn}
                onChange={(e) => {
                  setNisn(e.target.value);
                  if (error) setError('');
                }}
                onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                placeholder={isLocked ? "Sistem Masih Terkunci" : "Masukkan NISN (Contoh: 1234567801)"}
                className="w-full bg-white/5 border border-white/10 rounded-2xl py-6 pl-14 pr-6 text-white placeholder-gray-600 focus:outline-none focus:border-blue-500/50 focus:bg-white/[0.07] transition-all text-xl font-semibold tracking-wider disabled:cursor-not-allowed"
              />
            </div>
            <button 
              onClick={handleSearch}
              disabled={loading || isLocked}
              className="bg-blue-600 hover:bg-blue-500 text-white px-10 py-6 rounded-2xl font-black transition-all glow-blue disabled:opacity-50 flex items-center justify-center gap-3 active:scale-95 disabled:cursor-not-allowed"
            >
              {loading ? (
                <div className="flex items-center gap-3">
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                  <span>Memproses...</span>
                </div>
              ) : (
                <>Lihat Hasil <ArrowRight size={20} /></>
              )}
            </button>
          </div>

          {error && (
            <div className="mb-8 p-4 bg-red-500/10 border border-red-500/20 rounded-2xl flex items-center gap-3 text-red-400 text-sm animate-in fade-in zoom-in duration-300">
              <XCircle size={18} />
              {error}
            </div>
          )}

          {result && (
            <div className={`animate-in fade-in slide-in-from-bottom-8 duration-700 p-10 rounded-[2.5rem] border relative overflow-hidden ${result.status === 'LULUS' ? 'bg-green-500/10 border-green-500/20 shadow-[0_0_50px_-12px_rgba(34,197,94,0.2)]' : 'bg-red-500/10 border-red-500/20 shadow-[0_0_50px_-12px_rgba(239,68,68,0.2)]'}`}>
              
              {result.status === 'LULUS' && (
                <div className="absolute top-4 right-4 text-green-500/20 animate-float">
                  <Sparkles size={120} />
                </div>
              )}

              <div className="flex flex-col md:flex-row items-center md:items-start text-center md:text-left gap-8 relative z-10">
                <div className={`w-24 h-24 rounded-[2rem] flex items-center justify-center flex-shrink-0 shadow-2xl ${result.status === 'LULUS' ? 'bg-green-500 text-white' : 'bg-red-500 text-white'}`}>
                  {result.status === 'LULUS' ? <CheckCircle size={48} /> : <XCircle size={48} />}
                </div>
                
                <div className="space-y-4 flex-1">
                  <div className="space-y-1">
                    <div className="flex flex-col md:flex-row items-center gap-3">
                      <h3 className="text-3xl font-black tracking-tight">{result.name}</h3>
                      <span className={`px-4 py-1 rounded-full text-[10px] font-black uppercase tracking-widest ${result.status === 'LULUS' ? 'bg-green-500 text-black' : 'bg-red-500 text-white'}`}>
                        {result.status}
                      </span>
                    </div>
                    <p className="text-gray-500 font-bold text-sm">NISN: {result.nisn}</p>
                  </div>

                  <p className="text-gray-200 text-lg leading-relaxed font-medium">{result.message}</p>
                  
                  <div className="pt-6 border-t border-white/5 space-y-4">
                    <div className="flex items-start gap-3 italic text-gray-400 bg-white/5 p-6 rounded-3xl border border-white/5">
                      <BookOpen size={20} className="text-blue-500 flex-shrink-0 mt-1" />
                      <p className="text-sm leading-relaxed">"{result.quote}"</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {!result && !loading && !error && (
            <div className="flex flex-col items-center gap-4 py-8 text-gray-500 opacity-50">
              <div className="p-4 rounded-full bg-white/5 border border-white/5">
                <Info size={32} />
              </div>
              <p className="text-sm font-medium">Gunakan NISN 10 digit yang terdaftar di database.</p>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};

export default GraduationSection;

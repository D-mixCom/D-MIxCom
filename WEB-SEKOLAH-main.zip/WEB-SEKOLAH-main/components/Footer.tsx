
import React from 'react';
import { Facebook, Instagram, Twitter, Youtube, MapPin, Phone, Mail, GraduationCap } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer id="kontak" className="pt-24 pb-12 bg-black border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
          <div className="space-y-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center glow-blue">
                <GraduationCap className="text-white" size={24} />
              </div>
              <span className="text-xl font-bold">SMAN 1 TOJO</span>
            </div>
            <p className="text-gray-500 text-sm leading-relaxed">
              Pusat keunggulan pendidikan di Tojo Una-Una. Mencetak generasi tangguh, religius, dan berdaya saing global.
            </p>
            <div className="flex gap-4">
              {[Facebook, Instagram, Twitter, Youtube].map((Icon, i) => (
                <a key={i} href="#" className="w-10 h-10 glass rounded-xl flex items-center justify-center hover:bg-blue-600 hover:text-white transition-all">
                  <Icon size={18} />
                </a>
              ))}
            </div>
          </div>

          <div>
            <h4 className="text-lg font-bold mb-6">Tautan Cepat</h4>
            <ul className="space-y-4 text-sm text-gray-500">
              <li><a href="#" className="hover:text-blue-400 transition-colors">Profil Sekolah</a></li>
              <li><a href="#" className="hover:text-blue-400 transition-colors">Program Studi</a></li>
              <li><a href="#" className="hover:text-blue-400 transition-colors">PPDB Online</a></li>
              <li><a href="#" className="hover:text-blue-400 transition-colors">Kalender Akademik</a></li>
              <li><a href="#" className="hover:text-blue-400 transition-colors">Portal Siswa</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-bold mb-6">Hubungi Kami</h4>
            <ul className="space-y-4 text-sm text-gray-500">
              <li className="flex items-start gap-3">
                <MapPin size={18} className="text-blue-500 flex-shrink-0" />
                <span>Jl. Pendidikan No. 01, Kec. Tojo, Kab. Tojo Una-Una, Sulawesi Tengah.</span>
              </li>
              <li className="flex items-center gap-3">
                <Phone size={18} className="text-blue-500 flex-shrink-0" />
                <span>+62 (464) 123-4567</span>
              </li>
              <li className="flex items-center gap-3">
                <Mail size={18} className="text-blue-500 flex-shrink-0" />
                <span>info@sman1tojo.sch.id</span>
              </li>
            </ul>
          </div>

          <div className="rounded-3xl overflow-hidden glass h-48 relative border border-white/10">
            <div className="absolute inset-0 bg-blue-900/10 flex items-center justify-center">
              <span className="text-xs font-bold text-gray-400 uppercase tracking-widest">Peta Lokasi</span>
            </div>
            {/* Real map would go here, using image placeholder for now */}
            <img src="https://picsum.photos/seed/map/400/300" alt="Map" className="w-full h-full object-cover opacity-40" />
          </div>
        </div>

        <div className="pt-8 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-gray-600">
          <p>© 2026 SMAN 1 Tojo. All Rights Reserved.</p>
          <div className="flex gap-6">
            <a href="#">Privacy Policy</a>
            <a href="#">Terms of Service</a>
            <a href="#">Sitemap</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;


import { GoogleGenAI } from "@google/genai";

export class SchoolAssistantService {
  private ai: GoogleGenAI;
  private modelName = 'gemini-3-flash-preview';

  constructor() {
    // Initialized with process.env.API_KEY directly per SDK guidelines
    this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  }

  async getResponse(prompt: string, history: { role: string; content: string }[]) {
    try {
      const chat = this.ai.chats.create({
        model: this.modelName,
        config: {
          systemInstruction: `Anda adalah asisten virtual cerdas untuk SMAN 1 Tojo (Sekolah Menengah Atas Negeri 1 Tojo). 
          Tujuan Anda adalah membantu siswa, orang tua, dan calon siswa dengan informasi tentang sekolah.
          Informasi Utama SMAN 1 Tojo:
          - Visi: Mewujudkan insan yang berakhlak mulia, cerdas, terampil, dan peduli lingkungan.
          - Fasilitas: Laboratorium Komputer modern, Perpustakaan Digital, Lapangan Olahraga, dan Ruang Kelas Berbasis IT.
          - Program Unggulan: Kelas Sains, Ekstrakurikuler Robotik, Seni Budaya Lokal, dan Pramuka.
          - Alamat: Kabupaten Tojo Una-Una, Sulawesi Tengah.
          Berikan jawaban yang ramah, profesional, dan informatif dalam Bahasa Indonesia.`,
        },
      });

      const response = await chat.sendMessage({ message: prompt });
      return response.text;
    } catch (error) {
      console.error("Gemini Error:", error);
      return "Maaf, saya sedang mengalami kendala teknis. Silakan coba lagi nanti.";
    }
  }
}

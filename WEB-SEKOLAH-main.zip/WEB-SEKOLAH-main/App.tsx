
import React, { useState } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import BentoGrid from './components/BentoGrid';
import Assistant from './components/Assistant';
import Footer from './components/Footer';
import GraduationSection from './components/GraduationSection';
import AttendanceSection from './components/AttendanceSection';
import IDCardSection from './components/IDCardSection';
import ELearningSection from './components/ELearningSection';
import PPDBSection from './components/PPDBSection';
import { Sparkles, Star, Users, Award, ArrowLeft } from 'lucide-react';

type View = 'home' | 'kelulusan' | 'absensi' | 'id-card' | 'elearning' | 'ppdb';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<View>('home');

  const renderHome = () => (
    <>
      <Hero />
      <section className="relative z-20 -mt-12">
        <div className="max-w-5xl mx-auto px-4">
          <div className="glass p-8 rounded-[2.5rem] grid grid-cols-2 md:grid-cols-4 gap-8 shadow-2xl">
            <div className="text-center space-y-1">
              <div className="text-2xl font-black text-blue-500">25+</div>
              <div className="text-[10px] uppercase tracking-widest text-gray-500 font-bold">Tahun Berdiri</div>
            </div>
            <div className="text-center space-y-1">
              <div className="text-2xl font-black text-purple-500">500+</div>
              <div className="text-[10px] uppercase tracking-widest text-gray-500 font-bold">Lulusan/Tahun</div>
            </div>
            <div className="text-center space-y-1">
              <div className="text-2xl font-black text-green-500">45</div>
              <div className="text-[10px] uppercase tracking-widest text-gray-500 font-bold">Guru Profesional</div>
            </div>
            <div className="text-center space-y-1">
              <div className="text-2xl font-black text-pink-500">12</div>
              <div className="text-[10px] uppercase tracking-widest text-gray-500 font-bold">Klub Robotik</div>
            </div>
          </div>
        </div>
      </section>
      <BentoGrid />
      <section id="profil" className="py-24 relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-16 items-center">
            <div className="space-y-8 text-white">
              <div className="space-y-4">
                <h2 className="text-4xl font-extrabold">Visi Kami Untuk <span className="text-gradient">Masa Depan</span></h2>
                <p className="text-gray-400 leading-relaxed text-lg">
                  Menjadi pusat unggulan pendidikan yang adaptif terhadap perubahan teknologi global dengan tetap menjunjung tinggi nilai-nilai luhur dan kearifan lokal.
                </p>
              </div>
              <div className="space-y-6">
                {[
                  { icon: Sparkles, title: "Inovasi Tanpa Batas", desc: "Mendorong kreativitas siswa melalui proyek-proyek berbasis masalah nyata." },
                  { icon: Star, title: "Karakter Unggul", desc: "Membangun integritas dan etika yang kuat dalam setiap individu." },
                  { icon: Users, title: "Komunitas Inklusif", desc: "Lingkungan belajar yang ramah dan mendukung potensi setiap siswa." }
                ].map((item, i) => (
                  <div key={i} className="flex gap-6 p-6 rounded-2xl hover:bg-white/5 transition-all border border-transparent hover:border-white/10 group">
                    <div className="w-12 h-12 rounded-xl bg-blue-600/10 flex items-center justify-center text-blue-500 group-hover:bg-blue-600 group-hover:text-white transition-all">
                      <item.icon size={24} />
                    </div>
                    <div>
                      <h4 className="font-bold text-lg">{item.title}</h4>
                      <p className="text-sm text-gray-500 mt-1">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className="relative">
              <div className="aspect-square glass rounded-[3rem] p-12 overflow-hidden border border-white/10">
                <img src="https://picsum.photos/seed/vision/800/800" alt="Vision" className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-700 rounded-[2rem]" />
              </div>
              <div className="absolute -top-10 -left-10 w-40 h-40 glass rounded-full flex flex-col items-center justify-center gap-1 border-white/20 animate-float">
                <Award className="text-blue-500" size={32} />
                <span className="text-[10px] font-bold uppercase tracking-widest text-gray-400">Terbaik di</span>
                <span className="text-sm font-black text-white">Sulawesi Tengah</span>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );

  return (
    <div className="relative min-h-screen overflow-x-hidden print:bg-white print:text-black">
      <div className="print:hidden">
        <Navbar onNavigate={setCurrentView} currentView={currentView} />
      </div>
      <main className={`${currentView !== 'home' ? 'pt-24' : ''}`}>
        {currentView === 'home' && renderHome()}
        
        {currentView === 'ppdb' && (
           <div className="animate-in fade-in slide-in-from-top-4 duration-500">
             <div className="max-w-7xl mx-auto px-4 pt-8">
               <button onClick={() => setCurrentView('home')} className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors mb-4 font-bold">
                 <ArrowLeft size={18} /> Beranda
               </button>
             </div>
             <PPDBSection />
          </div>
        )}

        {currentView === 'elearning' && (
           <div className="animate-in fade-in slide-in-from-top-4 duration-500">
             <div className="max-w-7xl mx-auto px-4 pt-8">
               <button onClick={() => setCurrentView('home')} className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors mb-4 font-bold">
                 <ArrowLeft size={18} /> Beranda
               </button>
             </div>
             <ELearningSection />
          </div>
        )}

        {currentView === 'kelulusan' && (
          <div className="animate-in fade-in slide-in-from-top-4 duration-500">
             <div className="max-w-7xl mx-auto px-4 pt-8">
               <button onClick={() => setCurrentView('home')} className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors mb-4 font-bold">
                 <ArrowLeft size={18} /> Beranda
               </button>
             </div>
             <GraduationSection />
          </div>
        )}

        {currentView === 'absensi' && (
          <div className="animate-in fade-in slide-in-from-top-4 duration-500">
            <div className="max-w-7xl mx-auto px-4 pt-8">
               <button onClick={() => setCurrentView('home')} className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors mb-4 font-bold">
                 <ArrowLeft size={18} /> Beranda
               </button>
             </div>
            <AttendanceSection />
          </div>
        )}

        {currentView === 'id-card' && (
          <div className="animate-in fade-in slide-in-from-top-4 duration-500">
             <div className="max-w-7xl mx-auto px-4 pt-8 print:hidden">
               <button onClick={() => setCurrentView('home')} className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors mb-4 font-bold">
                 <ArrowLeft size={18} /> Beranda
               </button>
             </div>
             <IDCardSection />
          </div>
        )}
      </main>
      <div className="print:hidden">
        <Footer />
        <Assistant />
      </div>
    </div>
  );
};

export default App;
